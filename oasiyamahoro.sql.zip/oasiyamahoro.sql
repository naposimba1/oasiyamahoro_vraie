-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 27 juil. 2022 à 20:12
-- Version du serveur :  10.1.31-MariaDB
-- Version de PHP :  7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `oasiyamahoro`
--

-- --------------------------------------------------------

--
-- Doublure de structure pour la vue `approvisionner`
-- (Voir ci-dessous la vue réelle)
--
CREATE TABLE `approvisionner` (
`IdPF` int(11)
,`DescriptionPF` varchar(50)
,`Qte` double
,`PA` double
,`PV` double
,`DateFour` date
,`Etat` enum('activer','old')
);

-- --------------------------------------------------------

--
-- Structure de la table `banque`
--

CREATE TABLE `banque` (
  `IdBanque` int(11) NOT NULL,
  `NomBanque` varchar(50) NOT NULL,
  `Etat` char(10) DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `caisse`
--

CREATE TABLE `caisse` (
  `IdCaisse` int(11) NOT NULL,
  `Montant_caisse` double DEFAULT NULL,
  `Montant_dep` double DEFAULT NULL,
  `Date_C` date DEFAULT NULL,
  `Heure_C` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'depublier'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `IdCat` int(11) NOT NULL,
  `DescriptionCat` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `t_categorie` enum('Bar','Resto','Alimentation','Bar-Alimentation') COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`IdCat`, `DescriptionCat`, `t_categorie`, `Etat`) VALUES
(1, 'BIERE', 'Bar', 'activer'),
(2, 'AMSTEL', 'Bar', 'activer'),
(3, 'FANTA', 'Bar', 'activer'),
(4, 'VIVA', 'Bar', 'activer'),
(5, 'VIN', 'Bar', 'activer'),
(6, 'WHISKY', 'Bar', 'activer'),
(7, 'BOISSON EN PLASTIQUE', 'Bar', 'activer'),
(8, 'BOISSON EN CANET', 'Bar', 'activer'),
(9, 'BOISSON EN GODET', 'Bar', 'activer'),
(10, 'AKABENZI', 'Resto', 'activer'),
(11, 'BROCHETTE', 'Resto', 'activer'),
(12, 'POULET', 'Resto', 'activer'),
(13, 'LAPIN', 'Resto', 'activer'),
(14, 'VIANDE', 'Resto', 'activer'),
(15, 'NON VIANDE', 'Resto', 'activer'),
(16, 'FRITTE', 'Resto', 'activer'),
(17, 'SAUCE', 'Resto', 'activer'),
(18, 'POISSON', 'Resto', 'activer'),
(19, 'SPAGHETTI', 'Resto', 'activer'),
(20, 'PATE', 'Resto', 'activer'),
(21, 'POTAGE', 'Resto', 'activer'),
(22, 'OMELETTE', 'Resto', 'activer'),
(23, 'GATEAU', 'Resto', 'activer'),
(24, 'SALADE', 'Resto', 'activer'),
(26, 'THE', 'Resto', 'activer'),
(27, 'SOUPE', 'Resto', 'activer'),
(28, 'SAUCISSON', 'Alimentation', 'activer'),
(29, 'SARDINE', 'Alimentation', 'activer'),
(30, 'EAU', 'Alimentation', 'activer'),
(31, 'BOULETTE', 'Alimentation', 'activer'),
(32, 'BISCUIT', 'Alimentation', 'activer'),
(33, 'FROMAGE', 'Alimentation', 'activer'),
(34, 'JAMBON', 'Alimentation', 'activer'),
(35, 'PAIN', 'Alimentation', 'activer'),
(36, 'BLUE BAND', 'Alimentation', 'activer'),
(37, 'LAIT EN POUDRE', 'Alimentation', 'activer'),
(38, 'LAIT LIQUIDE', 'Alimentation', 'activer'),
(39, 'POISSON  A', 'Alimentation', 'activer'),
(40, 'UBUROBE', 'Resto', 'activer'),
(41, 'SAVON', 'Alimentation', 'activer'),
(42, 'HUILE', 'Alimentation', 'activer'),
(43, 'TAKE A WAY', 'Alimentation', 'activer'),
(44, 'ENVELOPE', 'Alimentation', 'activer'),
(45, 'SPAGUETTI', 'Alimentation', 'activer'),
(46, 'SACHET', 'Alimentation', 'activer'),
(47, 'STYLO', 'Alimentation', 'activer'),
(48, 'SAUCE TOMATE', 'Alimentation', 'activer'),
(49, 'BONBONS', 'Alimentation', 'activer'),
(50, 'JOJO', 'Alimentation', 'activer'),
(51, 'JUS', 'Alimentation', 'activer'),
(52, 'PAMPERS', 'Alimentation', 'activer'),
(53, 'COTEX', 'Alimentation', 'activer'),
(54, 'VIM', 'Alimentation', 'activer'),
(55, 'BOUGIE', 'Alimentation', 'activer'),
(56, 'SUCRE', 'Alimentation', 'activer'),
(57, 'PAPIER HYGIENIQUE', 'Alimentation', 'activer'),
(58, 'AUTRES DIVERS', 'Alimentation', 'activer'),
(59, 'MAYONNAISE', 'Alimentation', 'activer'),
(60, 'CHAMPIGNON', 'Alimentation', 'activer'),
(61, 'PILIPILI', 'Alimentation', 'activer'),
(62, 'BOUILLIT', 'Alimentation', 'activer'),
(63, 'FORMAT A QUATRE', 'Alimentation', 'activer'),
(64, 'MAGGY', 'Alimentation', 'activer'),
(65, 'CONFITURE', 'Alimentation', 'activer'),
(66, 'MIEL', 'Alimentation', 'activer'),
(67, 'BAYGONNE', 'Alimentation', 'activer'),
(68, 'TEKAWAY', 'Alimentation', 'activer'),
(69, 'SERVIETTE', 'Alimentation', 'activer'),
(70, 'OEUF', 'Alimentation', 'activer'),
(71, 'IBITUMBURA', 'Alimentation', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `IdCli` int(11) NOT NULL,
  `code_table` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateenr` date DEFAULT NULL,
  `etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`IdCli`, `code_table`, `dateenr`, `etat`) VALUES
(1, 'TABLE 1', '2021-10-12', 'activer'),
(2, 'TABLE 2', '2021-10-12', 'activer'),
(3, 'TABLE 3', '2021-10-12', 'activer'),
(4, 'TABLE 4', '2021-10-12', 'activer'),
(5, 'TABLE 5', '2021-10-12', 'activer'),
(6, 'TABLE 6', '2021-10-12', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `commandemp`
--

CREATE TABLE `commandemp` (
  `IdComMP` int(11) NOT NULL,
  `Matricule` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IdMP` int(11) DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateComMP` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'valider'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `commandepf`
--

CREATE TABLE `commandepf` (
  `IdComPF` int(11) NOT NULL,
  `code_serveur` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateComPF` date DEFAULT NULL,
  `HeureComPF` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `T_commande` enum('BAR','RESTO','ALIMENTATION') COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_cloture` date DEFAULT NULL,
  `cpt_jr_commande` int(11) DEFAULT '1',
  `Etat_ComPF` char(15) COLLATE utf8_unicode_ci DEFAULT 'encours'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `commandepf`
--

INSERT INTO `commandepf` (`IdComPF`, `code_serveur`, `DateComPF`, `HeureComPF`, `T_commande`, `date_cloture`, `cpt_jr_commande`, `Etat_ComPF`) VALUES
(1, 'BR004', '2022-06-28', '15:23:27', 'BAR', NULL, 1, 'traiter'),
(2, 'BR004', '2022-07-24', '21:00:58', 'RESTO', NULL, 1, 'traiter'),
(3, 'BR009', '2022-07-25', '18:37:52', 'BAR', NULL, 1, 'traiter'),
(4, 'BR004', '2022-07-25', '20:17:54', 'BAR', NULL, 2, 'encours'),
(5, 'BR004', '2022-07-26', '13:41:03', 'RESTO', NULL, 2, 'encours'),
(6, 'BR018', '2022-07-26', '13:42:58', 'RESTO', NULL, 1, 'encours'),
(7, 'BR009', '2022-07-27', '18:23:41', 'BAR', NULL, 2, 'encours'),
(8, 'BR008', '2022-07-27', '19:13:58', 'ALIMENTATION', NULL, 1, 'traiter'),
(9, 'BR008', '2022-07-27', '19:16:28', 'ALIMENTATION', NULL, 2, 'traiter'),
(10, 'BR008', '2022-07-27', '19:19:55', 'ALIMENTATION', NULL, 3, 'traiter'),
(11, 'BR008', '2022-07-27', '19:20:12', 'ALIMENTATION', NULL, 4, 'traiter'),
(12, 'BR008', '2022-07-27', '19:21:01', 'ALIMENTATION', NULL, 5, 'traiter'),
(13, 'BR008', '2022-07-27', '19:32:35', 'ALIMENTATION', NULL, 6, 'traiter'),
(14, 'BR008', '2022-07-27', '19:40:22', 'ALIMENTATION', NULL, 7, 'traiter'),
(15, 'BR008', '2022-07-27', '19:52:20', 'ALIMENTATION', NULL, 8, 'traiter'),
(16, 'BR008', '2022-07-27', '19:52:57', 'ALIMENTATION', NULL, 9, 'encours');

-- --------------------------------------------------------

--
-- Structure de la table `compte`
--

CREATE TABLE `compte` (
  `IdCompte` int(11) NOT NULL,
  `IdBanque` int(11) NOT NULL DEFAULT '0',
  `NumeroCompte` char(20) NOT NULL,
  `MontantTotal` double DEFAULT NULL,
  `Etat` char(10) DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `contenir`
--

CREATE TABLE `contenir` (
  `IdCo` int(11) NOT NULL,
  `IdPF` int(11) NOT NULL DEFAULT '0',
  `IdComPF` int(11) NOT NULL DEFAULT '0',
  `Qte` double DEFAULT NULL,
  `PU` double DEFAULT NULL,
  `PT` double DEFAULT NULL,
  `DateComPF` date DEFAULT NULL,
  `Heure` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_stab` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'encours'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `contenir_req`
--

CREATE TABLE `contenir_req` (
  `IdConteReq` int(11) NOT NULL,
  `IdReq` int(11) NOT NULL,
  `IdMP` int(11) NOT NULL,
  `QteR` double DEFAULT NULL,
  `DateR` date DEFAULT NULL,
  `heureR` time DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `depense`
--

CREATE TABLE `depense` (
  `iddepense` int(11) NOT NULL,
  `Matricule` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `description_dep` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `montant_dep` double DEFAULT NULL,
  `t_categorie` enum('Alimentation','Bar','Resto') COLLATE utf8_unicode_ci DEFAULT NULL,
  `dateenr` date DEFAULT NULL,
  `heure` time DEFAULT NULL,
  `etat_dep` char(15) COLLATE utf8_unicode_ci DEFAULT 'encours'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `detaille_application`
--

CREATE TABLE `detaille_application` (
  `IdDetaille` int(11) NOT NULL,
  `Titre` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `DescriptionT` longtext COLLATE utf8_unicode_ci,
  `Photo_Logo` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `DateDetaille` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'depublier'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `employes`
--

CREATE TABLE `employes` (
  `Matricule` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `Nom` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `Prenom` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Sexe` char(15) COLLATE utf8_unicode_ci NOT NULL,
  `DateNaiss` date DEFAULT NULL,
  `CNI` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `EtatCivil` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `Residence` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Telephone` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Droit` char(40) COLLATE utf8_unicode_ci NOT NULL,
  `Motdepasse` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Photo` char(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mention_operation` enum('administration','resto','bar','resto-bar','alimentation') COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateEnr` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `employes`
--

INSERT INTO `employes` (`Matricule`, `Nom`, `Prenom`, `Sexe`, `DateNaiss`, `CNI`, `EtatCivil`, `Residence`, `Telephone`, `Droit`, `Motdepasse`, `Photo`, `mention_operation`, `DateEnr`, `Etat`) VALUES
('AD001', 'NKURIKIYE', 'DONATIEN', 'Homme', '1983-02-08', '0204/62.345', 'Marié(e)', 'KAMENGE', '+257 79 832 639', 'administrateur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 'Capture.PNG', 'administration', '2016-07-08', 'activer'),
('BR002', 'BIGIRIMANA', 'JONAS', 'Homme', '1991-09-23', '0201/23.154', 'Célibataire', 'KANYOSHA, KAJIJI N', '+257 79 800 300', 'ass_responsable', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2017-09-05', 'activer'),
('BR003', 'BUKURU', 'JEANNE', 'Femme', '1999-03-05', '1002/89.369', 'Célibataire', 'KAMENGE', '75800900', 'snr_responsable', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2021-07-01', 'activer'),
('BR004', 'BUTOYI', 'BENIGNE', 'Femme', '1988-12-02', '0405/89.369', 'Marié(e)', 'BUYENZI', '71200300', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2021-07-02', 'activer'),
('BR005', 'BIZIMANA', 'ALEXIS', 'Homme', '1995-08-21', '0101/69.877', 'Célibataire', 'KAMENGE/MIRANGO I', '69346461', 'snr_responsable', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'alimentation', '2021-07-02', 'activer'),
('BR006', 'KALOLO', 'JEAN-JACQUES NAHIMAN', 'Homme', '1987-05-24', '0201/294.838', 'Célibataire', 'KAMENGE 13/18', '+25775966190', 'manager', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'administration', '2021-07-17', 'activer'),
('BR007', 'NIJIMBERE', 'RICHARD', 'Homme', '1985-06-28', '0201/216.964', 'Marié(e)', 'KAMENGE/MIRANGO I', '+25771428543', 'manager', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'administration', '2022-03-30', 'activer'),
('BR008', 'NAHIMANA', 'EMERY', 'Homme', '1990-05-02', '0201/125.228', 'Célibataire', 'GIHOSHA', '61254789', 'responsable', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'alimentation', '2022-06-21', 'activer'),
('BR009', 'NTUNZWENIMANA', 'AMADI', 'Homme', '1996-12-12', '0201/331.431', 'Célibataire', 'KAMENGE', '68032940', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2022-07-14', 'activer'),
('BR010', 'NSENGIYUMVA', 'FADHILI', 'Homme', '2005-05-16', '531.018/16.84', 'Célibataire', 'KUMATAFARI', '1111', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2022-07-14', 'activer'),
('BR011', 'BIGIRIMANA', 'EDMOND', 'Homme', '2002-12-14', '222', 'Célibataire', 'KAMENGE/MIRANGO I', '68143297', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR012', 'NAHIMANA', 'GLORIA', 'Femme', '1995-03-07', '531.13.06/82.61', 'Célibataire', 'CIBITOKE', '72308956', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR013', 'NZEYIMANA', 'BENIGNE ORNELLA', 'Femme', '1999-07-14', '0102/135.890', 'Célibataire', 'KAMENGE / MIRANGO II', '61116679', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR014', 'ININAHAZWE', 'MARIE ALLYVELLA', 'Femme', '2000-01-01', '1', 'Célibataire', 'KAMENGE MIRANGO II', '61151542', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR015', 'SUZANNE', 'MAYOMBE EUGENIE', 'Femme', '2002-04-24', '000', 'Célibataire', 'KAMENGE/ MIRANGO I', '68615789', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR016', 'IZERE', 'EDDY FERNAND', 'Homme', '1993-06-24', '531.0509/126.90', 'Célibataire', 'KAMENGE/ MIRANGO II', '72040245', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR017', 'KWIZERA', 'EUGENIE', 'Femme', '1991-01-01', '00000', 'Célibataire', 'KAMENGE', '61225872', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, NULL, '2022-07-14', 'activer'),
('BR018', 'MUKESHIMANA', 'LEATITIA', 'Femme', '1993-07-16', '0000', 'Célibataire', 'KUMATAFARI', '68057332', 'serveur', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2022-07-14', 'activer'),
('BR019', 'NIYUNGEKO', 'APOLLINAIRE', 'Homme', '1988-05-16', '0210/89.190', 'Célibataire', 'KAMENGE', '79849287', 'snr_responsable', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2022-07-14', 'activer'),
('BR020', 'NIYUNGEKO', 'ISAAC', 'Homme', '1990-10-25', '531.1502/1749', 'Célibataire', 'KAMENGE', '68060006', 'snr_responsable', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', NULL, 'resto-bar', '2022-07-14', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `exprimer`
--

CREATE TABLE `exprimer` (
  `IdExp` int(11) NOT NULL,
  `IdPF` int(11) NOT NULL DEFAULT '0',
  `Nbre` double DEFAULT '1',
  `DateEnr` date NOT NULL,
  `Etat` char(10) DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `exprimer`
--

INSERT INTO `exprimer` (`IdExp`, `IdPF`, `Nbre`, `DateEnr`, `Etat`) VALUES
(1, 2, 1, '2017-09-05', 'activer'),
(2, 1, 1, '2017-09-05', 'activer'),
(3, 4, 1, '2017-09-05', 'activer'),
(4, 8, 1, '2017-09-05', 'activer'),
(5, 7, 1, '2017-09-05', 'activer'),
(6, 6, 1, '2017-09-05', 'activer'),
(7, 3, 1, '2017-09-11', 'activer'),
(8, 5, 1, '2017-09-11', 'activer'),
(9, 11, 1, '2021-07-05', 'activer'),
(10, 9, 1, '2021-07-05', 'activer'),
(11, 10, 1, '2021-07-05', 'activer'),
(12, 12, 1, '2021-07-05', 'activer'),
(13, 16, 1, '2021-11-06', 'activer'),
(14, 14, 1, '2022-06-21', 'activer'),
(15, 13, 1, '2022-06-21', 'activer'),
(16, 0, 1, '2022-06-28', 'activer'),
(17, 219, 1, '2022-07-14', 'activer'),
(18, 220, 1, '2022-07-14', 'activer'),
(19, 191, 1, '2022-07-27', 'activer'),
(20, 238, 1, '2022-07-27', 'activer'),
(21, 45, 1, '2022-07-27', 'activer'),
(22, 227, 1, '2022-07-27', 'activer'),
(23, 184, 1, '2022-07-27', 'activer'),
(24, 133, 1, '2022-07-27', 'activer'),
(25, 142, 1, '2022-07-27', 'activer'),
(26, 248, 1, '2022-07-27', 'activer'),
(27, 216, 1, '2022-07-27', 'activer'),
(28, 254, 1, '2022-07-27', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `facture`
--

CREATE TABLE `facture` (
  `IdFact` int(11) NOT NULL,
  `IdF` int(11) NOT NULL DEFAULT '0',
  `Montant_En_Dette` double DEFAULT '0',
  `Montant_Paye` double DEFAULT '0',
  `dateenr` date DEFAULT NULL,
  `Etat_fact` char(15) COLLATE utf8_unicode_ci DEFAULT 'non-payer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `facture`
--

INSERT INTO `facture` (`IdFact`, `IdF`, `Montant_En_Dette`, `Montant_Paye`, `dateenr`, `Etat_fact`) VALUES
(4, 0, 10159300, 0, '2022-07-26', 'non-payer'),
(3, 2, 178741758, 0, '2022-07-14', 'non-payer');

-- --------------------------------------------------------

--
-- Structure de la table `fonction`
--

CREATE TABLE `fonction` (
  `IdFo` int(11) NOT NULL,
  `DescriptionFo` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `DateCre` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `fonction`
--

INSERT INTO `fonction` (`IdFo`, `DescriptionFo`, `DateCre`, `Etat`) VALUES
(1, 'administrateur', '2017-09-05', 'activer'),
(2, 'caissier', '2017-09-05', 'activer'),
(3, 'snr_responsable', '2022-06-02', 'activer'),
(4, 'serveur', '2021-07-02', 'activer'),
(5, 'manager', '2021-07-07', 'activer'),
(6, 'ass_responsable', '2022-06-02', 'activer'),
(7, 'responsable', '2022-07-27', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `fournirmp`
--

CREATE TABLE `fournirmp` (
  `IdFourMP` int(11) NOT NULL,
  `IdF` int(11) NOT NULL DEFAULT '0',
  `IdMP` int(11) NOT NULL DEFAULT '0',
  `PU` double DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateFour` date DEFAULT NULL,
  `date_exp` date DEFAULT NULL,
  `heure_fmp` time DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `fournirpf`
--

CREATE TABLE `fournirpf` (
  `IdFourPF` int(11) NOT NULL,
  `IdF` int(11) NOT NULL DEFAULT '0',
  `IdPF` int(11) NOT NULL DEFAULT '0',
  `PU` double DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateFour` date DEFAULT NULL,
  `mention_v` enum('alimentation','bar','resto','autres') COLLATE utf8_unicode_ci DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `fournirpf`
--

INSERT INTO `fournirpf` (`IdFourPF`, `IdF`, `IdPF`, `PU`, `Qte`, `DateFour`, `mention_v`, `responsable`, `Etat`) VALUES
(1, 2, 135, 300, 142, '2022-07-25', '', 'NIJIMBERE', 'activer'),
(2, 2, 130, 15000, 0, '2022-07-25', '', 'NIJIMBERE', 'activer'),
(3, 2, 135, 500, 142, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(4, 2, 134, 800, 44, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(5, 2, 133, 2400, 6, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(6, 2, 131, 1200, 0, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(7, 2, 190, 50, 6400, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(8, 2, 194, 50, 2200000, '2022-07-26', '', 'NAHIMANA', 'activer'),
(9, 2, 193, 50, 399980, '2022-07-26', '', 'NAHIMANA', 'activer'),
(10, 2, 195, 50, 399972, '2022-07-26', '', 'NAHIMANA', 'activer'),
(11, 2, 224, 25000, 12, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(12, 2, 167, 2000, 117, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(13, 2, 222, 12000, 18, '2022-07-26', '', 'NIJIMBERE', 'activer'),
(14, 2, 145, 8000, 6, '2022-07-26', '', 'NIJIMBERE', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `fournisseur`
--

CREATE TABLE `fournisseur` (
  `IdF` int(11) NOT NULL,
  `IdTypeF` int(11) NOT NULL DEFAULT '0',
  `Nom` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Adresse` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Telephone` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `fournisseur`
--

INSERT INTO `fournisseur` (`IdF`, `IdTypeF`, `Nom`, `Adresse`, `Telephone`, `Etat`) VALUES
(1, 2, 'DEPOT BITARYUMUNYU', 'KAMENGE', '79632584', 'activer'),
(2, 2, 'MARCHE', 'SION', '72156849', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `histcommandemp`
--

CREATE TABLE `histcommandemp` (
  `IdComMP` int(11) NOT NULL,
  `Matricule` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IdMP` int(11) DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateComMP` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'valider'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `histcontenir`
--

CREATE TABLE `histcontenir` (
  `IdCo` int(11) NOT NULL,
  `IdComPF` int(11) DEFAULT NULL,
  `IdPF` int(11) DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `PU` double DEFAULT NULL,
  `PT` double DEFAULT NULL,
  `DateComPF` date DEFAULT NULL,
  `HeureComPF` time DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'encours'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `histfacture`
--

CREATE TABLE `histfacture` (
  `IdFact` int(11) NOT NULL,
  `Matricule` char(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `IdF` int(11) NOT NULL DEFAULT '0',
  `Montant_Paye` double DEFAULT '0',
  `DateP` date DEFAULT NULL,
  `HeureP` time DEFAULT NULL,
  `code_facture` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Etat_fact` char(15) COLLATE utf8_unicode_ci DEFAULT 'verser'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `histfournirmp`
--

CREATE TABLE `histfournirmp` (
  `IdFourMP` int(11) NOT NULL,
  `IdF` int(11) DEFAULT NULL,
  `IdMP` int(11) DEFAULT NULL,
  `PU` double DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateFour` date DEFAULT NULL,
  `date_exp` date DEFAULT NULL,
  `heure_fmp` time DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `histfournirpf`
--

CREATE TABLE `histfournirpf` (
  `IdFourPF` int(11) NOT NULL,
  `IdF` int(11) DEFAULT NULL,
  `IdPF` int(11) DEFAULT NULL,
  `PU` double DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateFour` date DEFAULT NULL,
  `heure` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `histfournirpf`
--

INSERT INTO `histfournirpf` (`IdFourPF`, `IdF`, `IdPF`, `PU`, `Qte`, `DateFour`, `heure`, `responsable`, `Etat`) VALUES
(1, 2, 219, 10450, 12, '2022-07-14', NULL, 'NKURIKIYE', 'activer'),
(2, 2, 220, 7166, 30, '2022-07-14', NULL, 'NKURIKIYE', 'activer'),
(3, 2, 135, 291, 151, '2022-07-21', NULL, 'NIJIMBERE', 'activer'),
(4, 2, 134, 708, 59, '2022-07-21', NULL, 'NIJIMBERE', 'activer'),
(5, 2, 135, 300, 142, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(6, 2, 133, 2200, 10, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(7, 2, 131, 950, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(8, 2, 187, 505, 94, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(9, 2, 189, 510, 97, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(10, 2, 188, 405, 494, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(11, 2, 50, 541, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(12, 2, 51, 112, 68, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(13, 2, 52, 791, 7, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(14, 2, 45, 729, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(15, 2, 55, 1125, 31, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(16, 2, 56, 566, 150, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(17, 2, 57, 833, 19, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(18, 2, 82, 15000, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(19, 2, 125, 11500, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(20, 2, 126, 15000, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(21, 2, 130, 15000, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(22, 2, 130, 15000, 0, '2022-07-25', NULL, 'NIJIMBERE', 'activer'),
(23, 2, 135, 500, 142, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(24, 2, 134, 800, 44, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(25, 2, 136, 50, 1224, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(26, 2, 133, 2400, 6, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(27, 2, 131, 1200, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(28, 2, 186, 900, 82, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(29, 2, 199, 1800, 55, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(30, 2, 200, 3000, 4, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(31, 2, 201, 10000, 4, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(32, 2, 193, 50, 399980, '2022-07-26', NULL, 'NAHIMANA', 'activer'),
(33, 2, 194, 50, 2200000, '2022-07-26', NULL, 'NAHIMANA', 'activer'),
(34, 0, 195, 50, 199986, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(35, 0, 190, 50, 3200, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(36, 2, 190, 50, 6400, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(37, 2, 194, 50, 2200000, '2022-07-26', NULL, 'NAHIMANA', 'activer'),
(38, 2, 193, 50, 399980, '2022-07-26', NULL, 'NAHIMANA', 'activer'),
(39, 2, 195, 50, 399972, '2022-07-26', NULL, 'NAHIMANA', 'activer'),
(40, 2, 191, 200, 786, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(41, 2, 192, 50, 992, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(42, 2, 227, 3000, 35, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(43, 2, 228, 2000, 45, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(44, 2, 145, 8000, 7, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(45, 2, 221, 4500, 8, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(46, 2, 148, 100000, 2, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(47, 2, 149, 21000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(48, 2, 152, 18000, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(49, 2, 150, 23000, 9, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(50, 2, 222, 12000, 18, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(51, 2, 223, 1800, 15, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(52, 2, 224, 25000, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(53, 2, 224, 25000, 12, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(54, 2, 180, 8000, 10, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(55, 2, 174, 30000, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(56, 2, 225, 55000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(57, 2, 173, 76000, 1, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(58, 2, 161, 18000, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(59, 2, 162, 18000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(60, 2, 229, 5000, 6, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(61, 2, 165, 18000, 8, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(62, 2, 168, 2000, 25, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(63, 2, 230, 1400, 87, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(64, 2, 167, 2000, 117, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(65, 2, 167, 2000, 117, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(66, 2, 166, 800, 118, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(67, 2, 178, 4000, 5, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(68, 2, 207, 600, 96, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(69, 2, 238, 6000, 6, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(70, 2, 184, 500, 45, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(71, 2, 231, 200, 46, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(72, 2, 216, 500, 12, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(73, 2, 203, 500, 382, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(74, 2, 204, 500, 368, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(75, 2, 205, 3000, 47, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(76, 2, 175, 800, 266, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(77, 2, 176, 500, 418, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(78, 2, 177, 100, 166, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(79, 2, 215, 500, 49, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(80, 2, 237, 50, 2498, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(81, 2, 236, 3000, 4, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(82, 2, 210, 1200, 80, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(83, 2, 206, 2500, 12, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(84, 2, 211, 2000, 24, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(85, 2, 226, 25, 4900, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(86, 2, 154, 1000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(87, 2, 144, 600, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(88, 2, 153, 600, 5, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(89, 2, 147, 2500, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(90, 2, 151, 1300, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(91, 2, 245, 2500, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(92, 2, 235, 5000, 22, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(93, 2, 202, 2000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(94, 2, 241, 200, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(95, 2, 243, 300, 81, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(96, 2, 242, 500, 49, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(97, 2, 209, 300, 100, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(98, 2, 232, 5000, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(99, 2, 233, 8000, 2, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(100, 2, 234, 120, 6250, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(101, 2, 247, 2500, 36, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(102, 2, 248, 2000, 120, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(103, 2, 246, 600, 129, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(104, 2, 250, 50000, 3, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(105, 2, 222, 12000, 18, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(106, 2, 252, 3000, 36, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(107, 2, 251, 45000, 6, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(108, 2, 196, 800, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(109, 2, 208, 2500, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(110, 2, 197, 1000, 68, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(111, 2, 145, 8000, 6, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(112, 2, 171, 55000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(113, 2, 143, 1000, 0, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(114, 2, 239, 24, 21500, '2022-07-26', NULL, 'NIJIMBERE', 'activer'),
(115, 2, 253, 2500, 20, '2022-07-27', NULL, 'NKURIKIYE', 'activer'),
(116, 2, 254, 500, 200, '2022-07-27', NULL, 'NKURIKIYE', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `histproduire`
--

CREATE TABLE `histproduire` (
  `IdProd` int(11) NOT NULL,
  `IdReqMP` int(11) DEFAULT NULL,
  `IdPF` int(11) DEFAULT NULL,
  `Qte` double DEFAULT NULL,
  `DateProd` date DEFAULT NULL,
  `heureProd` time DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'executer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `histrequisitionner`
--

CREATE TABLE `histrequisitionner` (
  `IdReq` int(11) NOT NULL,
  `Matricule` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `IdMP` int(11) DEFAULT NULL,
  `QteR` double DEFAULT NULL,
  `DateR` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `hote`
--

CREATE TABLE `hote` (
  `Id` int(11) NOT NULL,
  `Nom` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Prenom` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Droit` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Telephone` char(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `DateConn` date DEFAULT NULL,
  `HeureConn` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HeureDecon` char(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Validite` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `hote`
--

INSERT INTO `hote` (`Id`, `Nom`, `Prenom`, `Droit`, `Telephone`, `DateConn`, `HeureConn`, `HeureDecon`, `Validite`, `Etat`) VALUES
(1, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-28', '18:22:11', NULL, 'Connexion', 'activer'),
(2, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '07:35:57', NULL, 'Connexion', 'activer'),
(3, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '18:22:47', NULL, 'Connexion', 'activer'),
(4, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '18:48:34', '19:17:12', 'deconnexion', 'desactiver'),
(5, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:17:24', '19:20:40', 'deconnexion', 'desactiver'),
(6, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:20:52', '19:21:41', 'deconnexion', 'desactiver'),
(7, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:21:50', NULL, 'Connexion', 'activer'),
(8, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:37:49', NULL, 'Connexion', 'activer'),
(9, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:38:20', '19:40:14', 'deconnexion', 'desactiver'),
(10, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:40:26', NULL, 'Connexion', 'activer'),
(11, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '19:42:01', NULL, 'Connexion', 'activer'),
(12, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '20:02:06', NULL, 'Connexion', 'activer'),
(13, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '20:17:15', NULL, 'Connexion', 'activer'),
(14, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-29', '20:34:16', NULL, 'Connexion', 'activer'),
(15, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-30', '08:04:25', NULL, 'Connexion', 'activer'),
(16, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-30', '09:35:31', NULL, 'Connexion', 'activer'),
(17, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-30', '12:03:39', NULL, 'Connexion', 'activer'),
(18, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-30', '12:17:02', NULL, 'Connexion', 'activer'),
(19, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-30', '18:55:27', NULL, 'Connexion', 'activer'),
(20, 'NAHIMANA', 'EMERY', 'snr_responsable', '61254789', '2022-06-30', '18:56:09', NULL, 'Connexion', 'activer'),
(21, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-06-30', '19:00:00', NULL, 'Connexion', 'activer'),
(22, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-01', '09:56:23', NULL, 'Connexion', 'activer'),
(23, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-14', '10:10:24', NULL, 'Connexion', 'activer'),
(24, 'BIZIMANA', 'ALEXIS', 'snr_responsable', '69346461', '2022-07-14', '10:13:04', NULL, 'Connexion', 'activer'),
(25, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-14', '10:39:26', NULL, 'Connexion', 'activer'),
(26, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-14', '12:25:05', NULL, 'Connexion', 'activer'),
(27, 'BIZIMANA', 'ALEXIS', 'snr_responsable', '69346461', '2022-07-14', '12:54:43', NULL, 'Connexion', 'activer'),
(28, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-14', '12:59:43', NULL, 'Connexion', 'activer'),
(29, 'nijimbere', 'RICHARD', 'manager', '+25771428543', '2022-07-21', '08:51:44', NULL, 'Connexion', 'activer'),
(30, 'BIZIMANA', 'ALEXIS', 'snr_responsable', '69346461', '2022-07-21', '09:01:18', NULL, 'Connexion', 'activer'),
(31, 'nijimbere', 'RICHARD', 'manager', '+25771428543', '2022-07-21', '09:03:30', NULL, 'Connexion', 'activer'),
(32, 'nijimbere', 'RICHARD', 'manager', '+25771428543', '2022-07-24', '20:47:20', NULL, 'Connexion', 'activer'),
(33, 'nijimbere', 'RICHARD', 'manager', '+25771428543', '2022-07-25', '18:30:01', '13:48:58', 'deconnexion', 'desactiver'),
(34, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-25', '19:39:22', NULL, 'Connexion', 'activer'),
(35, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-25', '20:12:23', '20:14:16', 'deconnexion', 'desactiver'),
(36, 'nahimana', 'EMERY', 'snr_responsable', '61254789', '2022-07-25', '20:14:52', '20:15:28', 'deconnexion', 'desactiver'),
(37, 'nahimana', 'EMERY', 'snr_responsable', '61254789', '2022-07-25', '20:15:39', '20:19:24', 'deconnexion', 'desactiver'),
(38, 'niyungeko', 'APOLLINAIRE', 'snr_responsable', '79849287', '2022-07-25', '20:17:42', NULL, 'Connexion', 'activer'),
(39, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-25', '20:19:33', NULL, 'Connexion', 'activer'),
(40, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-25', '21:03:56', NULL, 'Connexion', 'activer'),
(41, 'nahimana', 'EMERY', 'snr_responsable', '61254789', '2022-07-26', '13:55:07', '13:58:44', 'deconnexion', 'desactiver'),
(42, 'nahimana', 'EMERY', 'snr_responsable', '61254789', '2022-07-26', '14:09:36', '14:54:34', 'deconnexion', 'desactiver'),
(43, 'nahimana', 'EMERY', 'snr_responsable', '61254789', '2022-07-27', '18:22:50', '18:23:09', 'deconnexion', 'desactiver'),
(44, 'niyungeko', 'APOLLINAIRE', 'snr_responsable', '79849287', '2022-07-27', '18:23:32', '18:23:54', 'deconnexion', 'desactiver'),
(45, 'bizimana', 'ALEXIS', 'snr_responsable', '69346461', '2022-07-27', '18:24:18', NULL, 'Connexion', 'activer'),
(46, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-27', '18:48:45', NULL, 'Connexion', 'activer'),
(47, 'nahimana', 'EMERY', 'snr_responsable', '61254789', '2022-07-27', '18:51:45', NULL, 'Connexion', 'activer'),
(48, 'nahimana', 'EMERY', 'manager', '61254789', '2022-07-27', '18:53:19', NULL, 'Connexion', 'activer'),
(49, 'nahimana', 'EMERY', 'manager', '61254789', '2022-07-27', '19:06:47', '19:07:41', 'deconnexion', 'desactiver'),
(50, 'niyungeko', 'APOLLINAIRE', 'snr_responsable', '79849287', '2022-07-27', '19:07:55', '19:13:40', 'deconnexion', 'desactiver'),
(51, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-27', '19:12:02', NULL, 'Connexion', 'activer'),
(52, 'nahimana', 'EMERY', 'responsable', '61254789', '2022-07-27', '19:13:54', NULL, 'Connexion', 'activer'),
(53, 'nahimana', 'EMERY', 'responsable', '61254789', '2022-07-27', '19:16:12', '19:32:16', 'deconnexion', 'desactiver'),
(54, 'NKURIKIYE', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-27', '19:30:53', NULL, 'Connexion', 'activer'),
(55, 'nahimana', 'EMERY', 'responsable', '61254789', '2022-07-27', '19:32:29', '19:40:09', 'deconnexion', 'desactiver'),
(56, 'nahimana', 'EMERY', 'responsable', '61254789', '2022-07-27', '19:40:18', '20:10:46', 'deconnexion', 'desactiver'),
(57, 'nkurikiye', 'DONATIEN', 'administrateur', '+257 79 832 639', '2022-07-27', '19:55:05', NULL, 'Connexion', 'activer'),
(58, 'nahimana', 'EMERY', 'responsable', '61254789', '2022-07-27', '20:11:04', NULL, 'Connexion', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `logo`
--

CREATE TABLE `logo` (
  `IdLo` int(11) NOT NULL,
  `titre` varchar(50) COLLATE utf8_unicode_ci DEFAULT 'Bar-Resto',
  `description_logo` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_logo` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'depublier'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `logo`
--

INSERT INTO `logo` (`IdLo`, `titre`, `description_logo`, `date_logo`, `Etat`) VALUES
(1, 'Bar-Resto', 'logo.jpg', '2021-07-20', 'supprimer'),
(2, 'Bar-Resto', 'logo-1.png', '2021-07-20', 'supprimer'),
(3, 'Bar-Resto', 'logo.png', '2021-07-20', 'depublier'),
(4, 'Bar-Resto', 'logo-t.gif', '2021-07-20', 'depublier'),
(5, 'Bar-Resto', 'header-bg.png', '2022-06-30', 'publier');

-- --------------------------------------------------------

--
-- Structure de la table `matieresmp`
--

CREATE TABLE `matieresmp` (
  `IdMP` int(11) NOT NULL,
  `IdTypeMP` int(11) NOT NULL DEFAULT '0',
  `DescriptionMP` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `PU` double DEFAULT NULL,
  `QteTotale` double DEFAULT '0',
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `pays`
--

CREATE TABLE `pays` (
  `IdP` int(11) NOT NULL,
  `DescriptionP` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'publier'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `pays`
--

INSERT INTO `pays` (`IdP`, `DescriptionP`, `Etat`) VALUES
(1, 'Afghanistan', 'publier'),
(2, 'Afrique_Centrale', 'publier'),
(3, 'Afrique_du_Sud', 'publier'),
(4, 'Albanie', 'publier'),
(5, 'Algerie', 'publier'),
(6, 'Allemagne', 'publier'),
(7, 'Andorre', 'publier'),
(8, 'Angola', 'publier'),
(9, 'Anguilla', 'publier'),
(10, 'Arabie_Saoudite', 'publier'),
(11, 'Argentine', 'publier'),
(12, 'Armenie', 'publier'),
(13, 'Australie', 'publier'),
(14, 'Autriche', 'publier'),
(15, 'Azerbaidjan', 'publier'),
(16, 'Bahamas', 'publier'),
(17, 'Bangladesh', 'publier'),
(18, 'Barbade', 'publier'),
(19, 'Bahrein', 'publier'),
(20, 'Belgique', 'publier'),
(21, 'Belize', 'publier'),
(22, 'Benin', 'publier'),
(23, 'Bermudes', 'publier'),
(24, 'Bielorussie', 'publier'),
(25, 'Bolivie', 'publier'),
(26, 'Botswana', 'publier'),
(27, 'Bhoutan', 'publier'),
(28, 'Boznie_Herzegovine', 'publier'),
(29, 'Bresil', 'publier'),
(30, 'Brunei', 'publier'),
(31, 'Bulgarie', 'publier'),
(32, 'Burkina_Faso', 'publier'),
(33, 'Burundi', 'depublier'),
(34, 'Caiman', 'publier'),
(35, 'Cambodge', 'publier'),
(36, 'Cameroun', 'publier'),
(37, 'Canada', 'publier'),
(38, 'Canaries', 'publier'),
(39, 'Cap_Vert', 'publier'),
(40, 'Chili', 'publier'),
(41, 'Chine', 'publier'),
(42, 'Chypre', 'publier'),
(43, 'Colombie', 'publier'),
(44, 'Comores', 'publier'),
(45, 'Congo', 'publier'),
(46, 'Congo_democratique', 'publier'),
(47, 'Cook', 'publier'),
(48, 'Coree_du_Nord', 'publier'),
(49, 'Coree_du_Sud', 'publier'),
(50, 'Costa_Rica', 'publier'),
(51, 'C', 'publier'),
(52, 'Croatie', 'publier'),
(53, 'Cuba', 'publier'),
(54, 'Danemark', 'publier'),
(55, 'Djibouti', 'publier'),
(56, 'Dominique', 'publier'),
(57, 'Egypte', 'publier'),
(58, 'Emirats_Arabes_Unis', 'publier'),
(59, 'Equateur', 'publier'),
(60, 'Erythree', 'publier'),
(61, 'Espagne', 'publier'),
(62, 'Estonie', 'publier'),
(63, 'Etats_Unis', 'publier'),
(64, 'Ethiopie', 'publier'),
(65, 'Falkland', 'publier'),
(66, 'Feroe', 'publier'),
(67, 'Fidji', 'publier'),
(68, 'Finlande', 'publier'),
(69, 'France', 'publier'),
(70, 'Gabon', 'publier'),
(71, 'Gambie', 'publier'),
(72, 'Georgie', 'publier'),
(73, 'Ghana', 'publier'),
(74, 'Gibraltar', 'publier'),
(75, 'Grece', 'publier'),
(76, 'Grenade', 'publier'),
(77, 'Groenland', 'publier'),
(78, 'Guadeloupe', 'publier'),
(79, 'Guam', 'publier'),
(80, 'Guatemala', 'publier'),
(81, 'Guernesey', 'publier'),
(82, 'Guinee', 'publier'),
(83, 'Guinee_Bissau', 'publier'),
(84, 'Guinee_Equatoriale', 'publier'),
(85, 'Guyana', 'publier'),
(86, 'Guyane_Francaise', 'publier'),
(87, 'Haiti', 'publier'),
(88, 'Hawaii', 'publier'),
(89, 'Honduras', 'publier'),
(90, 'Hong_Kong', 'publier'),
(91, 'Hongrie', 'publier'),
(92, 'Inde', 'publier'),
(93, 'Indonesie', 'publier'),
(94, 'Iran', 'publier'),
(95, 'Iraq', 'publier'),
(96, 'Irlande', 'publier'),
(97, 'Islande', 'publier'),
(98, 'Israel', 'publier'),
(99, 'italie', 'publier'),
(100, 'Jamaique', 'publier'),
(101, 'Jan Mayen', 'publier'),
(102, 'Japon', 'publier'),
(103, 'Jersey', 'publier'),
(104, 'Jordanie', 'publier'),
(105, 'Kazakhstan', 'publier'),
(106, 'Kenya', 'publier'),
(107, 'Kirghizistan', 'publier'),
(108, 'Kiribati', 'publier'),
(109, 'Koweit', 'publier'),
(110, 'Laos', 'publier'),
(111, 'Lesotho', 'publier'),
(112, 'Lettonie', 'publier'),
(113, 'Liban', 'publier'),
(114, 'Liberia', 'publier'),
(115, 'Liechtenstein', 'publier'),
(116, 'Lituanie', 'publier'),
(117, 'Luxembourg', 'publier'),
(118, 'Lybie', 'publier'),
(119, 'Macao', 'publier'),
(120, 'Macedoine', 'publier'),
(121, 'Madagascar', 'publier'),
(122, 'Mad', 'publier'),
(123, 'Malaisie', 'publier'),
(124, 'Malawi', 'publier'),
(125, 'Maldives', 'publier'),
(126, 'Mali', 'publier'),
(127, 'Malte', 'publier'),
(128, 'Man', 'publier'),
(129, 'Mariannes du Nord', 'publier'),
(130, 'Maroc', 'publier'),
(131, 'Marshall', 'publier'),
(132, 'Martinique', 'publier'),
(133, 'Maurice', 'publier'),
(134, 'Mauritanie', 'publier'),
(135, 'Mayotte', 'publier'),
(136, 'Mexique', 'publier'),
(137, 'Micronesie', 'publier'),
(138, 'Midway', 'publier'),
(139, 'Moldavie', 'publier'),
(140, 'Monaco', 'publier'),
(141, 'Mongolie', 'publier'),
(142, 'Montserrat', 'publier'),
(143, 'Mozambique', 'publier'),
(144, 'Namibie', 'publier'),
(145, 'Nauru', 'publier'),
(146, 'Nepal', 'publier'),
(147, 'Nicaragua', 'publier'),
(148, 'Niger', 'publier'),
(149, 'Nigeria', 'publier'),
(150, 'Niue', 'publier'),
(151, 'Norfolk', 'publier'),
(152, 'Norvege', 'publier'),
(153, 'Nouvelle_Caledonie', 'publier'),
(154, 'Nouvelle_Zelande', 'publier'),
(155, 'Oman', 'publier'),
(156, 'Ouganda', 'publier'),
(157, 'Ouzbekistan', 'publier'),
(158, 'Pakistan', 'publier'),
(159, 'Palau', 'publier'),
(160, 'Palestine', 'publier'),
(161, 'Panama', 'publier'),
(162, 'Papouasie_Nouvelle_Guinee', 'publier'),
(163, 'Paraguay', 'publier'),
(164, 'Pays_Bas', 'publier'),
(165, 'Perou', 'publier'),
(166, 'Philippines', 'publier'),
(167, 'Pologne', 'publier'),
(168, 'Polynesie', 'publier'),
(169, 'Porto_Rico', 'publier'),
(170, 'Portugal', 'publier'),
(171, 'Qatar', 'publier'),
(172, 'Republique_Dominicaine', 'publier'),
(173, 'Republique_Tcheque', 'publier'),
(174, 'Reunion', 'publier'),
(175, 'Roumanie', 'publier'),
(176, 'Royaume_Uni', 'publier'),
(177, 'Russie', 'publier'),
(178, 'Rwanda', 'publier'),
(179, 'Sahara Occidental', 'publier'),
(180, 'Sainte_Lucie', 'publier'),
(181, 'Saint_Marin', 'publier'),
(182, 'Salomon', 'publier'),
(183, 'Salvador', 'publier'),
(184, 'Samoa_Occidentales', 'publier'),
(185, 'Samoa_Americaine', 'publier'),
(186, 'Sao_Tome_et_Principe', 'publier'),
(187, 'Senegal', 'publier'),
(188, 'Seychelles', 'publier'),
(189, 'Sierra Leone', 'publier'),
(190, 'Singapour', 'publier'),
(191, 'Slovaquie', 'publier'),
(192, 'Slovenie', 'publier'),
(193, 'Somalie', 'publier'),
(194, 'Soudan', 'publier'),
(195, 'Soudan du Sud', 'publier'),
(196, 'Sri_Lanka', 'publier'),
(197, 'Suede', 'publier'),
(198, 'Suisse', 'publier'),
(199, 'Surinam', 'publier'),
(200, 'Swaziland', 'publier'),
(201, 'Syrie', 'publier'),
(202, 'Tadjikistan', 'publier'),
(203, 'Taiwan', 'publier'),
(204, 'Tonga', 'publier'),
(205, 'Tanzanie', 'publier'),
(206, 'Tchad', 'publier'),
(207, 'Thailande', 'publier'),
(208, 'Tibet', 'publier'),
(209, 'Timor_Oriental', 'publier'),
(210, 'Togo', 'publier'),
(211, 'Trinite_et_Tobago', 'publier'),
(212, 'Tristan de cuncha', 'publier'),
(213, 'Tunisie', 'publier'),
(214, 'Turmenistan', 'publier'),
(215, 'Turquie', 'publier'),
(216, 'Ukraine', 'publier'),
(217, 'Uruguay', 'publier'),
(218, 'Vanuatu', 'publier'),
(219, 'Vatican', 'publier'),
(220, 'Venezuela', 'publier'),
(221, 'Vierges_Americaines', 'publier'),
(222, 'Vierges_Britanniques', 'publier'),
(223, 'Vietnam', 'publier'),
(224, 'Wake', 'publier'),
(225, 'Wallis et Futuma', 'publier'),
(226, 'Yemen', 'publier'),
(227, 'Yougoslavie', 'publier'),
(228, 'Zambie', 'publier'),
(229, 'Zimbabwe', 'publier');

-- --------------------------------------------------------

--
-- Structure de la table `prix`
--

CREATE TABLE `prix` (
  `IdPrix` int(11) NOT NULL,
  `IdPF` int(11) NOT NULL DEFAULT '0',
  `PU` double DEFAULT NULL,
  `PUA` double DEFAULT '0',
  `DateVal` date NOT NULL,
  `Etat` enum('activer','old') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `prix`
--

INSERT INTO `prix` (`IdPrix`, `IdPF`, `PU`, `PUA`, `DateVal`, `Etat`) VALUES
(1, 219, 12000, 10416, '2022-07-14', 'activer'),
(2, 133, 2400, 2400, '2022-07-25', 'activer'),
(3, 131, 1200, 1200, '2022-07-25', 'activer'),
(4, 187, 700, 505, '2022-07-25', 'activer'),
(5, 189, 700, 510, '2022-07-25', 'activer'),
(6, 188, 700, 405, '2022-07-25', 'activer'),
(7, 186, 900, 900, '2022-07-25', 'activer'),
(8, 51, 1000, 812, '2022-07-25', 'activer'),
(9, 50, 800, 541, '2022-07-25', 'activer'),
(10, 45, 1000, 729, '2022-07-25', 'activer'),
(11, 52, 1000, 791, '2022-07-25', 'activer'),
(12, 199, 1800, 1800, '2022-07-25', 'activer'),
(13, 200, 3000, 3000, '2022-07-25', 'activer'),
(14, 201, 10000, 10000, '2022-07-25', 'activer'),
(15, 193, 50, 50, '2022-07-25', 'activer'),
(16, 194, 50, 50, '2022-07-25', 'activer'),
(17, 195, 50, 50, '2022-07-25', 'activer'),
(18, 190, 50, 50, '2022-07-25', 'activer'),
(19, 191, 200, 200, '2022-07-25', 'activer'),
(20, 192, 50, 50, '2022-07-25', 'activer'),
(21, 56, 900, 566, '2022-07-25', 'activer'),
(22, 55, 1800, 1125, '2022-07-25', 'activer'),
(23, 57, 1000, 833, '2022-07-25', 'activer'),
(24, 145, 8000, 8000, '2022-07-25', 'activer'),
(25, 148, 100000, 100000, '2022-07-25', 'activer'),
(26, 149, 21000, 21000, '2022-07-25', 'activer'),
(27, 152, 18000, 18000, '2022-07-25', 'activer'),
(28, 150, 23000, 23000, '2022-07-25', 'activer'),
(29, 115, 600, 533, '2022-07-25', 'activer'),
(30, 173, 76000, 76000, '2022-07-25', 'activer'),
(31, 171, 55000, 55000, '2022-07-25', 'activer'),
(32, 174, 30000, 30000, '2022-07-25', 'activer'),
(33, 221, 4500, 4500, '2022-07-25', 'activer'),
(34, 222, 5000, 12000, '2022-07-25', 'activer'),
(35, 135, 500, 500, '2022-07-25', 'activer'),
(36, 134, 800, 800, '2022-07-25', 'activer'),
(37, 223, 1800, 1800, '2022-07-25', 'activer'),
(38, 224, 25000, 25000, '2022-07-25', 'activer'),
(39, 161, 18000, 18000, '2022-07-25', 'activer'),
(40, 162, 18000, 18000, '2022-07-25', 'activer'),
(41, 165, 15000, 18000, '2022-07-25', 'activer'),
(42, 168, 2000, 2000, '2022-07-25', 'activer'),
(43, 167, 2000, 2000, '2022-07-25', 'activer'),
(44, 166, 800, 800, '2022-07-25', 'activer'),
(45, 179, 3000, 2400, '2022-07-25', 'activer'),
(46, 178, 4000, 4000, '2022-07-25', 'activer'),
(47, 207, 600, 600, '2022-07-25', 'activer'),
(48, 184, 500, 500, '2022-07-25', 'activer'),
(49, 216, 500, 500, '2022-07-25', 'activer'),
(50, 203, 500, 500, '2022-07-25', 'activer'),
(51, 204, 500, 500, '2022-07-25', 'activer'),
(52, 205, 3000, 3000, '2022-07-25', 'activer'),
(53, 175, 800, 800, '2022-07-25', 'activer'),
(54, 176, 500, 500, '2022-07-25', 'activer'),
(55, 177, 50, 100, '2022-07-25', 'activer'),
(56, 215, 500, 500, '2022-07-25', 'activer'),
(57, 218, 50, 38, '2022-07-25', 'activer'),
(58, 210, 1200, 1200, '2022-07-25', 'activer'),
(59, 211, 2000, 2000, '2022-07-25', 'activer'),
(60, 7, 3000, 1833, '2022-07-25', 'activer'),
(61, 8, 2000, 1450, '2022-07-25', 'activer'),
(62, 154, 1000, 1000, '2022-07-26', 'activer'),
(63, 144, 600, 600, '2022-07-26', 'activer'),
(64, 153, 600, 600, '2022-07-26', 'activer'),
(65, 151, 1300, 1300, '2022-07-26', 'activer'),
(66, 147, 2500, 2500, '2022-07-26', 'activer'),
(67, 202, 2000, 2000, '2022-07-26', 'activer'),
(68, 209, 300, 300, '2022-07-26', 'activer'),
(69, 236, 3500, 3000, '2022-07-26', 'activer'),
(70, 238, 6000, 6000, '2022-07-26', 'activer'),
(71, 231, 200, 200, '2022-07-26', 'activer'),
(72, 229, 5000, 5000, '2022-07-26', 'activer'),
(73, 230, 1400, 1400, '2022-07-26', 'activer'),
(74, 234, 12000, 120, '2022-07-26', 'activer'),
(75, 232, 5000, 5000, '2022-07-26', 'activer'),
(76, 233, 8000, 8000, '2022-07-26', 'activer'),
(77, 245, 2500, 2500, '2022-07-26', 'activer'),
(78, 242, 500, 500, '2022-07-26', 'activer'),
(79, 243, 300, 300, '2022-07-26', 'activer'),
(80, 241, 200, 200, '2022-07-26', 'activer'),
(81, 254, 600, 500, '2022-07-27', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `produirepf`
--

CREATE TABLE `produirepf` (
  `IdProd` int(11) NOT NULL,
  `IdReq` int(11) NOT NULL,
  `IdPF` int(11) NOT NULL DEFAULT '0',
  `Qte` double DEFAULT NULL,
  `PU_Prod` double DEFAULT '0',
  `DateProd` date DEFAULT NULL,
  `heureProd` time DEFAULT NULL,
  `responsable` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'encours'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `produirepf`
--

INSERT INTO `produirepf` (`IdProd`, `IdReq`, `IdPF`, `Qte`, `PU_Prod`, `DateProd`, `heureProd`, `responsable`, `Etat`) VALUES
(2, 4, 13, 7, 8000, '2021-07-10', '10:29:19', 'MATARO', 'executer'),
(3, 4, 14, 12, 12500, '2021-07-10', '10:29:32', 'MATARO', 'executer'),
(15, 8, 12, 12, 4000, '2021-07-17', '13:15:06', 'NIYONZIMA', 'encours'),
(5, 2, 13, 23, 8000, '2021-07-10', '10:42:16', 'MATARO', 'executer'),
(6, 2, 14, 10, 12500, '2021-07-10', '10:42:25', 'MATARO', 'executer'),
(14, 6, 12, 1, 4000, '2021-07-10', '17:34:17', 'MATARO', 'encours'),
(8, 1, 13, 12, 8000, '2021-07-10', '10:42:45', 'MATARO', 'executer'),
(9, 1, 14, 5, 12500, '2021-07-10', '10:42:51', 'MATARO', 'executer'),
(13, 6, 12, 34, 4000, '2021-07-10', '17:27:38', 'MATARO', 'executer'),
(11, 6, 13, 8, 8000, '2021-07-10', '17:23:26', 'MATARO', 'executer'),
(12, 6, 14, 56, 12500, '2021-07-10', '17:23:32', 'MATARO', 'executer'),
(16, 8, 14, 5, 12500, '2021-07-17', '13:15:27', 'NIYONZIMA', 'encours'),
(17, 9, 13, 4, 8000, '2021-07-24', '14:44:28', 'BIGIRIMANA', 'executer');

-- --------------------------------------------------------

--
-- Structure de la table `produitsfinis`
--

CREATE TABLE `produitsfinis` (
  `IdPF` int(11) NOT NULL,
  `IdCat` int(11) NOT NULL DEFAULT '0',
  `DescriptionPF` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `QteTotale` double DEFAULT '0',
  `QteTotale_v` double DEFAULT '0',
  `mention` enum('alimentation','bar','resto','bar-alimentation','resto-alimentation','bar-resto-alimentation','bar-resto') COLLATE utf8_unicode_ci DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `produitsfinis`
--

INSERT INTO `produitsfinis` (`IdPF`, `IdCat`, `DescriptionPF`, `QteTotale`, `QteTotale_v`, `mention`, `Etat`) VALUES
(1, 1, 'PRIMUS 72 CL', 0, 0, 'bar', 'desactiver'),
(2, 1, 'PRIMUS 50 CL', 0, 0, 'bar', 'activer'),
(3, 1, 'LEFFE PETIT', 0, 0, 'bar', 'activer'),
(4, 1, 'LEFFE GRAND', 0, 0, 'bar', 'activer'),
(5, 1, 'SENATOR', 0, 0, 'bar', 'activer'),
(6, 1, 'HEINKEN', 0, 0, 'bar', 'activer'),
(7, 2, 'AMSTEL 65 CL', 0, 0, 'bar', 'activer'),
(8, 2, 'AMSTEL 50CL', 0, 0, 'bar', 'activer'),
(9, 2, 'BOCK', 0, 0, 'bar', 'activer'),
(10, 2, 'ROYALE', 0, 0, 'bar', 'activer'),
(11, 3, 'SPRITE', 0, 0, 'bar', 'activer'),
(12, 3, 'ORANGE', 0, 0, 'bar', 'activer'),
(13, 3, 'COCA COLA', 0, 0, 'bar', 'activer'),
(14, 3, 'CITRON', 0, 0, 'bar', 'activer'),
(15, 3, 'TONIC', 0, 0, 'bar', 'activer'),
(16, 4, 'MALT', 0, 0, 'bar', 'activer'),
(17, 4, 'TANGAWIZI', 0, 0, 'bar', 'activer'),
(18, 5, 'DOMPO GRAND', 0, 0, 'bar', 'activer'),
(19, 5, 'DOMPO PETIT', 0, 0, 'bar', 'activer'),
(20, 5, 'DROSTY GRAND', 0, 0, 'bar', 'activer'),
(21, 5, 'DROSTY PETIT', 0, 0, 'bar', 'activer'),
(22, 5, 'CELLIER D_OR', 0, 0, 'bar', 'activer'),
(23, 5, 'VIN DE MESSE', 0, 0, 'bar', 'activer'),
(24, 5, 'OXYNAMS', 0, 0, 'bar', 'activer'),
(25, 5, 'HEAVEN', 0, 0, 'bar', 'activer'),
(26, 5, 'EUREKA', 0, 0, 'bar', 'activer'),
(27, 5, 'MARTINI ROUGE', 0, 0, 'bar', 'activer'),
(28, 5, 'MARTINI BLANC', 0, 0, 'bar', 'activer'),
(29, 5, 'FOUR COUSIN', 0, 0, 'bar', 'activer'),
(30, 5, 'CELLAR', 0, 0, 'bar', 'activer'),
(31, 6, 'JACK DANIEL', 0, 0, 'bar', 'activer'),
(32, 6, 'CHIVAS', 0, 0, 'bar', 'activer'),
(33, 6, 'RED LABEL', 0, 0, 'bar', 'activer'),
(34, 6, 'J AND B', 0, 0, 'bar', 'activer'),
(35, 6, 'HUNTERS CHOISE', 0, 0, 'bar', 'activer'),
(36, 6, 'BLACK CAFE', 0, 0, 'bar', 'activer'),
(37, 6, 'BLACK WHISKY', 0, 0, 'bar', 'activer'),
(38, 6, 'KIKI', 0, 0, 'bar', 'activer'),
(39, 6, 'KARIBU GRAND', 0, 0, 'bar', 'activer'),
(40, 6, 'KARIBU PETIT', 0, 0, 'bar', 'activer'),
(41, 6, 'BEST WISKY', 0, 0, 'bar', 'activer'),
(42, 6, 'BLACK PETIT', 0, 0, 'bar', 'activer'),
(43, 7, 'FOURSANA', 0, 0, 'bar', 'activer'),
(44, 7, 'MIRINDA', 0, 0, 'bar', 'activer'),
(45, 7, 'APPLE', 0, 0, 'bar', 'activer'),
(46, 7, 'MALTI GRAND', 0, 0, 'bar', 'activer'),
(47, 7, 'MALTI PETIT', 0, 0, 'bar', 'activer'),
(48, 7, 'MALTI CAFE', 0, 0, 'bar', 'activer'),
(49, 7, 'COCA COLA', 0, 0, 'bar', 'activer'),
(50, 7, 'BOOM', 0, 0, 'bar', 'activer'),
(51, 7, 'EMBE', 0, 0, 'bar', 'activer'),
(52, 7, 'ENERGIE', 0, 0, 'bar', 'activer'),
(53, 7, 'RAHA TANGAWIZI', 0, 0, 'bar', 'activer'),
(54, 7, 'COOL UP', 0, 0, 'bar', 'activer'),
(55, 7, 'KINJU GRAND', 0, 0, 'bar', 'activer'),
(56, 7, 'KINJU PETIT', 0, 0, 'bar', 'activer'),
(57, 7, 'AQUAVIE GAZ', 0, 0, 'bar', 'activer'),
(58, 8, 'BAVARIA', 0, 0, 'bar', 'activer'),
(59, 8, 'OJ', 0, 0, 'bar', 'activer'),
(60, 8, 'SMIRNOFF', 0, 0, 'bar', 'activer'),
(61, 8, 'POWER HORSE', 0, 0, 'bar', 'activer'),
(62, 9, 'MARTINI ROUGE', 0, 0, 'bar', 'activer'),
(63, 9, 'MARTINI BLANC', 0, 0, 'bar', 'activer'),
(64, 9, 'CHIVAS', 0, 0, 'bar', 'activer'),
(65, 9, 'JACK DANIEL', 0, 0, 'bar', 'activer'),
(66, 9, 'RED LABEL', 0, 0, 'bar', 'activer'),
(67, 9, 'J AND B', 0, 0, 'bar', 'activer'),
(68, 9, 'CELLAR EN CARTON', 0, 0, 'bar', 'activer'),
(69, 11, 'BROCHETTE DE BOEUF ', 0, 0, 'resto', 'activer'),
(70, 11, 'BROCHETTE DE POISSON', 0, 0, 'resto', 'activer'),
(71, 11, 'BROCHETTE DE PORC ', 0, 0, 'resto', 'activer'),
(72, 11, 'BROCHETTE AGASENDABABOYI ', 0, 0, 'resto', 'activer'),
(73, 11, 'BROCHETTE SAUCISSON ', 0, 0, 'resto', 'activer'),
(74, 11, 'BOULETTE SIMPLE (1/4 KG)', 0, 0, 'resto', 'activer'),
(75, 11, 'BOULETTE SIMPLE (1/2 KG)', 0, 0, 'resto', 'activer'),
(76, 11, 'BOULETTE SIMPLE (1 KG)', 0, 0, 'resto', 'activer'),
(77, 11, 'JARRET', 0, 0, 'resto', 'activer'),
(78, 11, 'RAGOUT', 0, 0, 'resto', 'activer'),
(79, 12, ' POULET (1/4)', 0, 0, 'resto', 'activer'),
(80, 12, ' POULET (1/2)', 0, 0, 'resto', 'activer'),
(81, 12, 'POULET ENTIER', 0, 0, 'resto', 'activer'),
(82, 13, 'AGAKWAVU', 0, 0, 'alimentation', 'activer'),
(83, 14, 'VIANDE AUX OIGNONS', 0, 0, 'resto', 'activer'),
(84, 14, 'VIANDE AVEC SAUCE', 0, 0, 'resto', 'activer'),
(85, 15, 'RIZ BLANC', 0, 0, 'resto', 'activer'),
(86, 15, 'HARICOTS (BITOTO)', 0, 0, 'resto', 'activer'),
(87, 15, 'PETITS POIS', 0, 0, 'resto', 'activer'),
(88, 15, 'POMME DE TERRE NATURE', 0, 0, 'resto', 'activer'),
(89, 15, 'POMME DE TERRE SAUTE AU LAIT', 0, 0, 'resto', 'activer'),
(90, 15, 'POMME DE TERRE SAUTE SANSLAIT', 0, 0, 'resto', 'activer'),
(91, 15, 'BANANE NATURE (AGATOKE)', 0, 0, 'resto', 'activer'),
(92, 16, 'FRITTE DE BANANE', 0, 0, 'resto', 'activer'),
(93, 16, 'FRITTE DE POMME DE TERRE', 0, 0, 'resto', 'activer'),
(94, 17, 'SAUCE  BOLOGNAISE', 0, 0, 'resto', 'activer'),
(95, 17, 'SAUCE AUBERGINE', 0, 0, 'resto', 'activer'),
(96, 17, 'SAUCE AUX LENGA LENGA', 0, 0, 'resto', 'activer'),
(97, 18, 'MUKEKE', 0, 0, 'resto', 'activer'),
(98, 18, 'NDAGALA SIMPLE', 0, 0, 'resto', 'activer'),
(99, 19, 'SPAGHETTI A LA SAUCE BOLOGNAISE', 0, 0, 'resto', 'activer'),
(100, 19, 'SPAGHETTIA LA SAUCE BASILIQUE', 0, 0, 'resto', 'activer'),
(101, 19, 'SPAGHETTI_MACARRONI SIMPLE', 0, 0, 'resto', 'activer'),
(102, 19, 'SPAGHETTI A  LA SAUCE AUBERGINE', 0, 0, 'resto', 'activer'),
(103, 20, 'PATE DE MAIS', 0, 0, 'resto', 'activer'),
(104, 20, 'PATE DE MANIOC ', 0, 0, 'resto', 'activer'),
(105, 20, 'SOUPE', 0, 0, 'resto', 'activer'),
(106, 21, 'POTAGE IKINONO', 0, 0, 'resto', 'activer'),
(107, 21, 'POTAGE TETE CHEVRE (MOITIE)', 0, 0, 'resto', 'activer'),
(108, 22, 'OMELETTE FRITTE', 0, 0, 'resto', 'activer'),
(109, 22, 'OMELETTE OIGNONS', 0, 0, 'resto', 'activer'),
(110, 22, 'OMELETTE POIVRONS', 0, 0, 'resto', 'activer'),
(111, 22, 'OMELETTE JAMBON FROMAGE', 0, 0, 'resto', 'activer'),
(112, 22, 'OMELETTE MAISON', 0, 0, 'resto', 'activer'),
(113, 22, 'OMELETTE NATURE', 0, 0, 'resto', 'activer'),
(114, 22, 'OMELETTE TOMATE', 0, 0, 'resto', 'activer'),
(115, 22, 'OEUF DUR', 0, 0, 'resto', 'activer'),
(116, 23, 'GATEAU AU CHOCOLA', 0, 0, 'resto', 'activer'),
(117, 23, 'GATEAU CROSTATE', 0, 0, 'resto', 'activer'),
(118, 23, 'GATEAU AUX CONFUTURE', 0, 0, 'resto', 'activer'),
(119, 23, 'GATEAU AVEC DECORS', 0, 0, 'resto', 'activer'),
(120, 23, 'PIZZA MAFIOZO', 0, 0, 'resto', 'activer'),
(121, 24, 'SALADE LEGUMES', 0, 0, 'resto', 'activer'),
(122, 24, 'SALADE FRUITS', 0, 0, 'resto', 'activer'),
(123, 24, 'SALADE CHEF', 0, 0, 'resto', 'activer'),
(124, 26, 'THE AU LAIT', 0, 0, 'resto', 'activer'),
(125, 28, 'ORDINAIRE', 0, 0, 'alimentation', 'activer'),
(126, 28, 'SPECIAL', 0, 0, 'alimentation', 'activer'),
(127, 30, 'GR KNJU', 0, 0, 'alimentation', 'activer'),
(128, 30, 'PT KINJU', 0, 0, 'alimentation', 'activer'),
(129, 30, 'AQUAVIE GAZ', 0, 0, 'alimentation', 'activer'),
(130, 31, 'B SPECIALE', 0, 0, 'alimentation', 'activer'),
(131, 32, 'BISCUIT SEC', 0, 0, 'alimentation', 'activer'),
(132, 31, 'ORDINAIRE', 0, 0, 'alimentation', 'activer'),
(133, 32, 'BISCUIT A L ORANGE', 0, 0, 'alimentation', 'activer'),
(134, 32, 'NUTRO', 0, 0, 'alimentation', 'activer'),
(135, 32, 'NICE', 0, 0, 'alimentation', 'activer'),
(136, 32, 'GRUCOSE', 0, 0, 'alimentation', 'activer'),
(137, 26, 'THE DU BURUNDI', 0, 0, 'resto', 'activer'),
(138, 35, 'P VIANDE', 0, 0, 'alimentation', 'activer'),
(139, 26, 'THE GINGIMBRE', 0, 0, 'resto', 'activer'),
(140, 26, 'CAFE FORT', 0, 0, 'resto', 'activer'),
(141, 26, 'AFRICAN THEE', 0, 0, 'resto', 'activer'),
(142, 26, 'AFRICAN CAFFEE', 0, 0, 'resto', 'activer'),
(143, 35, 'P STELL', 0, 0, 'alimentation', 'activer'),
(144, 35, 'P MIEL', 0, 0, 'alimentation', 'activer'),
(145, 18, 'THON', 0, 0, 'alimentation', 'activer'),
(146, 18, 'SARDINE', 0, 0, 'alimentation', 'activer'),
(147, 35, 'P COUPE (GRD)', 0, 0, '', 'activer'),
(148, 37, 'NIDO GRAND', 0, 0, 'alimentation', 'activer'),
(149, 37, 'NIDO PETIT', 0, 0, 'alimentation', 'activer'),
(150, 37, 'FRANCE LAIT', 0, 0, 'alimentation', 'activer'),
(151, 35, 'P COUPE (PT)', 0, 0, 'alimentation', 'activer'),
(152, 37, 'CELELAC', 0, 0, 'alimentation', 'activer'),
(153, 0, 'P STADIN', 0, 0, 'alimentation', 'activer'),
(154, 35, 'P FRANCAIS', 0, 0, 'alimentation', 'activer'),
(155, 35, 'PAIN FRANCAIS', 0, 0, 'resto', 'activer'),
(156, 39, 'SARDINE', 0, 0, 'alimentation', 'activer'),
(157, 3, 'FANTA', 0, 0, 'bar', 'activer'),
(158, 39, 'THON', 0, 0, 'alimentation', 'activer'),
(159, 38, 'LAIT IMFYUFYU 1/2 L', 0, 0, 'alimentation', 'activer'),
(160, 38, 'LAIT IKIVUGUTO 1/2 L', 0, 0, 'alimentation', 'activer'),
(161, 41, 'DETERGENT', 0, 0, 'alimentation', 'activer'),
(162, 41, 'NETTOYANT', 0, 0, 'alimentation', 'activer'),
(163, 38, 'LAIT IMFYUFYU 1 L', 0, 0, 'alimentation', 'activer'),
(164, 38, 'LAIT IKIVUGUTO 1 L', 0, 0, 'alimentation', 'activer'),
(165, 41, 'DESINFECTANT', 0, 0, 'alimentation', 'activer'),
(166, 41, 'STARS', 0, 0, 'alimentation', 'activer'),
(167, 41, 'FAMILLY', 0, 0, 'alimentation', 'activer'),
(168, 41, 'OMO', 0, 0, 'alimentation', 'activer'),
(169, 42, 'TOURNE SOL 1L', 0, 0, 'alimentation', 'activer'),
(170, 42, 'TOURNE SOL 5L', 0, 0, 'alimentation', 'activer'),
(171, 42, 'COOKI 5L', 0, 0, 'alimentation', 'activer'),
(172, 42, 'COOKI 1L', 0, 0, 'alimentation', 'activer'),
(173, 42, 'COOKI 10L', 0, 0, 'alimentation', 'activer'),
(174, 42, 'COOKI 3L', 0, 0, 'alimentation', 'activer'),
(175, 0, 'PAPIER MOUCHOIR', 0, 0, 'alimentation', 'activer'),
(176, 44, 'SAC', 0, 0, 'alimentation', 'activer'),
(177, 44, 'SIMPLE', 0, 0, 'alimentation', 'activer'),
(178, 45, 'MACALONIES', 0, 0, 'alimentation', 'activer'),
(179, 45, 'LUCIA', 0, 0, 'alimentation', 'activer'),
(180, 42, 'OLIVE VERT', 0, 0, 'alimentation', 'activer'),
(181, 46, 'PETIT', 0, 0, 'alimentation', 'activer'),
(182, 46, 'MOYEN', 0, 0, 'alimentation', 'activer'),
(183, 46, 'GRAND', 0, 0, 'alimentation', 'activer'),
(184, 47, 'BIC', 0, 0, 'alimentation', 'activer'),
(185, 47, 'SMOOTHLINE', 0, 0, 'alimentation', 'activer'),
(186, 48, 'SALSA', 0, 0, 'alimentation', 'activer'),
(187, 48, 'KENZY', 0, 0, 'alimentation', 'activer'),
(188, 48, 'TOP TOMATE', 0, 0, 'alimentation', 'activer'),
(189, 48, 'EUROPA', 0, 0, 'alimentation', 'activer'),
(190, 49, 'MILK KANDY', 0, 0, 'alimentation', 'activer'),
(191, 49, 'BIG DAD', 0, 0, 'alimentation', 'activer'),
(192, 49, 'FILIMBI', 0, 0, 'alimentation', 'activer'),
(193, 50, 'GOGO ', 0, 0, 'alimentation', 'activer'),
(194, 50, 'TIKITI ', 0, 0, 'alimentation', 'activer'),
(195, 50, 'FUN ORANGE ', 0, 0, 'alimentation', 'activer'),
(196, 51, 'BOOM A', 0, 0, 'alimentation', 'activer'),
(197, 51, 'EMBE A', 0, 0, 'alimentation', 'activer'),
(198, 51, 'JUS NATUREL A', 0, 0, 'alimentation', 'activer'),
(199, 51, 'FRUITO PETIT A', 0, 0, 'alimentation', 'activer'),
(200, 51, 'FRUITO MOYEN A', 0, 0, 'alimentation', 'activer'),
(201, 51, 'FRUITO GRAND A', 0, 0, 'alimentation', 'activer'),
(202, 51, 'JUS NATUREL MARAKUDJA', 0, 0, 'alimentation', 'activer'),
(203, 52, 'MAMI LOVE', 0, 0, 'alimentation', 'activer'),
(204, 52, 'MAYA', 0, 0, 'alimentation', 'activer'),
(205, 53, 'COTEX QUEEN', 0, 0, 'alimentation', 'activer'),
(206, 54, 'VIM KIK', 0, 0, 'alimentation', 'activer'),
(207, 55, 'BOUGIE', 0, 0, 'alimentation', 'activer'),
(208, 56, 'SUCRE SOSUMO', 0, 0, 'alimentation', 'activer'),
(209, 56, 'SUCRE VANILI', 0, 0, 'alimentation', 'activer'),
(210, 57, 'PAPIER HYGIENIQUE', 0, 0, 'alimentation', 'activer'),
(211, 58, 'IMIKENKE', 0, 0, 'alimentation', 'activer'),
(212, 58, 'SEL', 0, 0, 'alimentation', 'activer'),
(213, 58, 'SUCRE', 0, 0, 'alimentation', 'activer'),
(214, 58, 'LAIT LIQUIDE', 0, 0, 'alimentation', 'activer'),
(215, 58, 'CURE DENT', 0, 0, 'alimentation', 'activer'),
(216, 58, 'ARACHIDE', 0, 0, 'alimentation', 'activer'),
(217, 58, 'CHIPSI', 0, 0, 'alimentation', 'activer'),
(218, 58, 'PAPIER A FORMAT 4', 0, 0, 'alimentation', 'activer'),
(219, 59, 'CULINO', 0, 0, 'alimentation', 'desactiver'),
(220, 59, 'EVERY DAY', 0, 0, 'alimentation', 'activer'),
(221, 36, 'BLUE BAND', 0, 0, 'alimentation', 'activer'),
(222, 60, 'CHAMPIGNON', 0, 0, 'alimentation', 'activer'),
(223, 61, 'PILIPILI', 0, 0, 'alimentation', 'activer'),
(224, 42, 'OLIVE', 0, 0, 'alimentation', 'activer'),
(225, 42, 'GOLDEN 5L', 0, 0, 'alimentation', 'activer'),
(226, 33, 'FROMAGE', 0, 0, 'alimentation', 'activer'),
(227, 29, 'ANNY', 0, 0, 'alimentation', 'activer'),
(228, 29, 'MASTER', 0, 0, 'alimentation', 'activer'),
(229, 41, 'HAND WASH', 0, 0, 'alimentation', 'activer'),
(230, 41, 'SHAZA', 0, 0, 'alimentation', 'activer'),
(231, 47, 'OBAMA', 0, 0, 'alimentation', 'activer'),
(232, 65, 'FRAISE', 0, 0, 'alimentation', 'activer'),
(233, 65, 'EXTRAT QUATRE', 0, 0, 'alimentation', 'activer'),
(234, 66, 'MIEL', 0, 0, 'alimentation', 'activer'),
(235, 64, 'MAGGY', 0, 0, 'alimentation', 'activer'),
(236, 62, 'TAGATA', 0, 0, 'alimentation', 'activer'),
(237, 63, 'FORMAT QUATRE', 0, 0, 'alimentation', 'activer'),
(238, 67, 'BAYGONNE', 0, 0, 'alimentation', 'activer'),
(239, 37, 'DAIRY BASED', 0, 0, 'alimentation', 'activer'),
(240, 0, 'GRAND', 0, 0, 'alimentation', 'activer'),
(241, 46, 'S PETIT', 0, 0, 'alimentation', 'activer'),
(242, 46, 'S GRAND', 0, 0, 'alimentation', 'activer'),
(243, 46, 'S MOYEN', 0, 0, 'alimentation', 'desactiver'),
(244, 49, 'MILK CANDY', 0, 0, 'alimentation', 'activer'),
(245, 35, 'P COLONE', 0, 0, 'alimentation', 'activer'),
(246, 70, 'OEUF', 0, 0, 'alimentation', 'activer'),
(247, 69, 'SERVIETTE', 0, 0, 'alimentation', 'activer'),
(248, 68, 'TAKAWAY', 0, 0, 'alimentation', 'activer'),
(249, 42, 'CHAMPIGNON', 0, 0, 'alimentation', 'activer'),
(250, 42, 'SOF WAY', 0, 0, 'alimentation', 'activer'),
(251, 37, 'NIDO MOYEN', 0, 0, 'alimentation', 'activer'),
(252, 19, 'SANTA LUCIA', 0, 0, 'alimentation', 'activer'),
(253, 52, 'YY', 0, 0, 'alimentation', 'activer'),
(254, 71, 'BEIGNET', 0, 0, 'alimentation', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `produits_image`
--

CREATE TABLE `produits_image` (
  `id_img` int(11) NOT NULL,
  `IdPF` int(11) NOT NULL,
  `titre` varchar(50) NOT NULL,
  `description_img` varchar(100) NOT NULL,
  `date_img` date DEFAULT NULL,
  `etat_img` char(15) DEFAULT 'depublier'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `produits_image`
--

INSERT INTO `produits_image` (`id_img`, `IdPF`, `titre`, `description_img`, `date_img`, `etat_img`) VALUES
(1, 1, 'SPRITE', 'sprite.jpg', '2021-07-20', 'publier'),
(2, 6, 'POULET', 'poulet.jpg', '2021-07-20', 'publier'),
(3, 5, 'PRIMUS 75CL', 'primus.jpg', '2021-07-20', 'publier'),
(4, 3, 'CITRON', 'citron.jpg', '2021-07-20', 'depublier'),
(5, 4, 'ORANGE', 'orange.jpg', '2021-07-20', 'depublier'),
(6, 13, 'RAGOUT', 'ragout.jpg', '2021-07-20', 'depublier'),
(7, 7, 'POULET(0,5)', 'poulet-0-5-.jpg', '2022-05-15', 'depublier'),
(8, 8, 'POULET(0,25)', 'poulet-0-25-.jpg', '2022-05-15', 'depublier'),
(9, 9, 'BOCK', 'bock.png', '2022-06-30', 'depublier');

-- --------------------------------------------------------

--
-- Structure de la table `rel_retour_pf`
--

CREATE TABLE `rel_retour_pf` (
  `id_tpf` int(11) NOT NULL,
  `idpf` int(11) NOT NULL,
  `qte_retour` double DEFAULT '0',
  `date_retour` date DEFAULT NULL,
  `heure_retour` char(10) DEFAULT NULL,
  `matricule` char(30) NOT NULL,
  `etat_tpf` char(15) DEFAULT 'activer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `rel_transfert_pf`
--

CREATE TABLE `rel_transfert_pf` (
  `id_tpf` int(11) NOT NULL,
  `idpf` int(11) NOT NULL,
  `qte` double DEFAULT NULL,
  `date_tpf` date DEFAULT NULL,
  `heure_tpf` char(10) DEFAULT NULL,
  `matricule` char(30) NOT NULL,
  `etat_tpf` char(15) DEFAULT 'activer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `requisitionner`
--

CREATE TABLE `requisitionner` (
  `IdReq` int(11) NOT NULL,
  `Matricule` char(30) NOT NULL,
  `DateReq` date DEFAULT NULL,
  `heureReq` time DEFAULT NULL,
  `EtatReq` char(15) DEFAULT 'encours'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `requisitionner`
--

INSERT INTO `requisitionner` (`IdReq`, `Matricule`, `DateReq`, `heureReq`, `EtatReq`) VALUES
(1, 'BR007', '2022-07-24', '20:58:47', 'encours'),
(2, 'BR008', '2022-07-26', '14:30:23', 'encours');

-- --------------------------------------------------------

--
-- Structure de la table `tb_sous_stock`
--

CREATE TABLE `tb_sous_stock` (
  `id_sst` int(11) NOT NULL,
  `idpf` int(11) NOT NULL,
  `qte_sst` double DEFAULT NULL,
  `mention_sst` char(15) DEFAULT 'PF'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `tb_stock`
--

CREATE TABLE `tb_stock` (
  `idst` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `qtetotale` double DEFAULT '0',
  `mention_st` enum('MP','PF') DEFAULT NULL,
  `etat_st` char(15) DEFAULT 'activer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `tb_stock`
--

INSERT INTO `tb_stock` (`idst`, `id`, `qtetotale`, `mention_st`, `etat_st`) VALUES
(2, 219, 12, 'PF', 'activer'),
(3, 220, 30, 'PF', 'activer'),
(4, 135, 435, 'PF', 'activer'),
(5, 134, 103, 'PF', 'activer'),
(6, 133, 16, 'PF', 'activer'),
(7, 131, 0, 'PF', 'activer'),
(8, 187, 94, 'PF', 'activer'),
(9, 189, 97, 'PF', 'activer'),
(10, 188, 494, 'PF', 'activer'),
(11, 50, 0, 'PF', 'activer'),
(12, 51, 68, 'PF', 'activer'),
(13, 52, 7, 'PF', 'activer'),
(14, 45, 0, 'PF', 'activer'),
(15, 55, 31, 'PF', 'activer'),
(16, 56, 150, 'PF', 'activer'),
(17, 57, 19, 'PF', 'activer'),
(18, 82, 0, 'PF', 'activer'),
(19, 125, 0, 'PF', 'activer'),
(20, 126, 0, 'PF', 'activer'),
(21, 130, 0, 'PF', 'activer'),
(22, 136, 1224, 'PF', 'activer'),
(23, 186, 82, 'PF', 'activer'),
(24, 199, 55, 'PF', 'activer'),
(25, 200, 4, 'PF', 'activer'),
(26, 201, 4, 'PF', 'activer'),
(27, 193, 599970, 'PF', 'activer'),
(28, 194, 2400000, 'PF', 'activer'),
(29, 195, 599958, 'PF', 'activer'),
(30, 190, 9600, 'PF', 'activer'),
(31, 191, 786, 'PF', 'activer'),
(32, 192, 992, 'PF', 'activer'),
(33, 227, 35, 'PF', 'activer'),
(34, 228, 45, 'PF', 'activer'),
(35, 145, 13, 'PF', 'activer'),
(36, 221, 8, 'PF', 'activer'),
(37, 148, 2, 'PF', 'activer'),
(38, 149, 0, 'PF', 'activer'),
(39, 152, 3, 'PF', 'activer'),
(40, 150, 9, 'PF', 'activer'),
(41, 222, 24, 'PF', 'activer'),
(42, 223, 15, 'PF', 'activer'),
(43, 224, 15, 'PF', 'activer'),
(44, 180, 10, 'PF', 'activer'),
(45, 174, 3, 'PF', 'activer'),
(46, 225, 0, 'PF', 'activer'),
(47, 173, 1, 'PF', 'activer'),
(48, 161, 3, 'PF', 'activer'),
(49, 162, 0, 'PF', 'activer'),
(50, 229, 6, 'PF', 'activer'),
(51, 165, 8, 'PF', 'activer'),
(52, 168, 25, 'PF', 'activer'),
(53, 230, 87, 'PF', 'activer'),
(54, 167, 234, 'PF', 'activer'),
(55, 166, 118, 'PF', 'activer'),
(56, 178, 5, 'PF', 'activer'),
(57, 207, 96, 'PF', 'activer'),
(58, 238, 6, 'PF', 'activer'),
(59, 184, 45, 'PF', 'activer'),
(60, 231, 46, 'PF', 'activer'),
(61, 216, 12, 'PF', 'activer'),
(62, 203, 382, 'PF', 'activer'),
(63, 204, 368, 'PF', 'activer'),
(64, 205, 47, 'PF', 'activer'),
(65, 175, 266, 'PF', 'activer'),
(66, 176, 418, 'PF', 'activer'),
(67, 177, 166, 'PF', 'activer'),
(68, 215, 49, 'PF', 'activer'),
(69, 237, 2498, 'PF', 'activer'),
(70, 236, 4, 'PF', 'activer'),
(71, 210, 80, 'PF', 'activer'),
(72, 206, 12, 'PF', 'activer'),
(73, 211, 24, 'PF', 'activer'),
(74, 226, 4900, 'PF', 'activer'),
(75, 154, 0, 'PF', 'activer'),
(76, 144, 3, 'PF', 'activer'),
(77, 153, 5, 'PF', 'activer'),
(78, 147, 3, 'PF', 'activer'),
(79, 151, 0, 'PF', 'activer'),
(80, 245, 3, 'PF', 'activer'),
(81, 235, 22, 'PF', 'activer'),
(82, 202, 0, 'PF', 'activer'),
(83, 241, 0, 'PF', 'activer'),
(84, 243, 81, 'PF', 'activer'),
(85, 242, 49, 'PF', 'activer'),
(86, 209, 100, 'PF', 'activer'),
(87, 232, 3, 'PF', 'activer'),
(88, 233, 2, 'PF', 'activer'),
(89, 234, 6250, 'PF', 'activer'),
(90, 247, 36, 'PF', 'activer'),
(91, 248, 120, 'PF', 'activer'),
(92, 246, 129, 'PF', 'activer'),
(93, 250, 3, 'PF', 'activer'),
(94, 252, 36, 'PF', 'activer'),
(95, 251, 6, 'PF', 'activer'),
(96, 196, 0, 'PF', 'activer'),
(97, 208, 0, 'PF', 'activer'),
(98, 197, 68, 'PF', 'activer'),
(99, 171, 0, 'PF', 'activer'),
(100, 143, 0, 'PF', 'activer'),
(101, 239, 21500, 'PF', 'activer'),
(102, 253, 20, 'PF', 'activer'),
(103, 254, 200, 'PF', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `typefournisseur`
--

CREATE TABLE `typefournisseur` (
  `IdTypeF` int(11) NOT NULL,
  `DescriptionType` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `typefournisseur`
--

INSERT INTO `typefournisseur` (`IdTypeF`, `DescriptionType`, `Etat`) VALUES
(1, 'INTERNE', 'activer'),
(2, 'EXTERNE', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `type_matieresp`
--

CREATE TABLE `type_matieresp` (
  `IdTypeMP` int(11) NOT NULL,
  `DescriptionType` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'activer'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `type_matieresp`
--

INSERT INTO `type_matieresp` (`IdTypeMP`, `DescriptionType`, `Etat`) VALUES
(1, 'PATATES', 'activer'),
(2, 'LEGUMMES', 'activer'),
(3, 'EPICES', 'activer'),
(4, 'VIANDE', 'activer');

-- --------------------------------------------------------

--
-- Structure de la table `verser_monaie`
--

CREATE TABLE `verser_monaie` (
  `IdVerMonaie` int(11) NOT NULL,
  `IdCompte` int(11) NOT NULL DEFAULT '0',
  `Matricule` char(20) NOT NULL DEFAULT '',
  `MontantVerse` double DEFAULT NULL,
  `DateVerse` date DEFAULT NULL,
  `Etat` char(10) DEFAULT 'debiter'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `ville`
--

CREATE TABLE `ville` (
  `IdV` int(11) NOT NULL,
  `IdP` int(11) NOT NULL DEFAULT '0',
  `DescriptionV` char(30) COLLATE utf8_unicode_ci NOT NULL,
  `DateV` date DEFAULT NULL,
  `Etat` char(15) COLLATE utf8_unicode_ci DEFAULT 'depublier'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la vue `approvisionner`
--
DROP TABLE IF EXISTS `approvisionner`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `approvisionner`  AS  select `produitsfinis`.`IdPF` AS `IdPF`,`produitsfinis`.`DescriptionPF` AS `DescriptionPF`,sum(`fournirpf`.`Qte`) AS `Qte`,`fournirpf`.`PU` AS `PA`,`prix`.`PU` AS `PV`,`fournirpf`.`DateFour` AS `DateFour`,`prix`.`Etat` AS `Etat` from (`prix` join (`produitsfinis` join `fournirpf` on((`fournirpf`.`IdPF` = `produitsfinis`.`IdPF`))) on((`produitsfinis`.`IdPF` = `prix`.`IdPF`))) where (`prix`.`Etat` = 'activer') group by `produitsfinis`.`DescriptionPF`,`fournirpf`.`PU` ;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `banque`
--
ALTER TABLE `banque`
  ADD PRIMARY KEY (`IdBanque`);

--
-- Index pour la table `caisse`
--
ALTER TABLE `caisse`
  ADD PRIMARY KEY (`IdCaisse`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`IdCat`);

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`IdCli`);

--
-- Index pour la table `commandemp`
--
ALTER TABLE `commandemp`
  ADD PRIMARY KEY (`IdComMP`);

--
-- Index pour la table `commandepf`
--
ALTER TABLE `commandepf`
  ADD PRIMARY KEY (`IdComPF`);

--
-- Index pour la table `compte`
--
ALTER TABLE `compte`
  ADD PRIMARY KEY (`IdCompte`,`IdBanque`),
  ADD KEY `IdBanque` (`IdBanque`);

--
-- Index pour la table `contenir`
--
ALTER TABLE `contenir`
  ADD PRIMARY KEY (`IdCo`,`IdPF`,`IdComPF`),
  ADD KEY `IdComPF` (`IdComPF`),
  ADD KEY `IdPF` (`IdPF`);

--
-- Index pour la table `contenir_req`
--
ALTER TABLE `contenir_req`
  ADD PRIMARY KEY (`IdConteReq`,`IdReq`,`IdMP`),
  ADD KEY `IdPF` (`IdMP`),
  ADD KEY `Matricule` (`IdReq`);

--
-- Index pour la table `depense`
--
ALTER TABLE `depense`
  ADD PRIMARY KEY (`iddepense`,`Matricule`),
  ADD KEY `Matricule` (`Matricule`);

--
-- Index pour la table `detaille_application`
--
ALTER TABLE `detaille_application`
  ADD PRIMARY KEY (`IdDetaille`);

--
-- Index pour la table `employes`
--
ALTER TABLE `employes`
  ADD PRIMARY KEY (`Matricule`);

--
-- Index pour la table `exprimer`
--
ALTER TABLE `exprimer`
  ADD PRIMARY KEY (`IdExp`,`IdPF`),
  ADD KEY `IdPF` (`IdPF`);

--
-- Index pour la table `facture`
--
ALTER TABLE `facture`
  ADD PRIMARY KEY (`IdFact`,`IdF`),
  ADD KEY `IdF` (`IdF`);

--
-- Index pour la table `fonction`
--
ALTER TABLE `fonction`
  ADD PRIMARY KEY (`IdFo`);

--
-- Index pour la table `fournirmp`
--
ALTER TABLE `fournirmp`
  ADD PRIMARY KEY (`IdFourMP`,`IdF`,`IdMP`),
  ADD KEY `IdF` (`IdF`),
  ADD KEY `IdMP` (`IdMP`);

--
-- Index pour la table `fournirpf`
--
ALTER TABLE `fournirpf`
  ADD PRIMARY KEY (`IdFourPF`,`IdF`,`IdPF`),
  ADD KEY `IdF` (`IdF`),
  ADD KEY `IdPF` (`IdPF`);

--
-- Index pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  ADD PRIMARY KEY (`IdF`,`IdTypeF`),
  ADD KEY `IdTypeF` (`IdTypeF`);

--
-- Index pour la table `histcommandemp`
--
ALTER TABLE `histcommandemp`
  ADD PRIMARY KEY (`IdComMP`);

--
-- Index pour la table `histcontenir`
--
ALTER TABLE `histcontenir`
  ADD PRIMARY KEY (`IdCo`);

--
-- Index pour la table `histfacture`
--
ALTER TABLE `histfacture`
  ADD PRIMARY KEY (`IdFact`,`Matricule`,`IdF`);

--
-- Index pour la table `histfournirmp`
--
ALTER TABLE `histfournirmp`
  ADD PRIMARY KEY (`IdFourMP`);

--
-- Index pour la table `histfournirpf`
--
ALTER TABLE `histfournirpf`
  ADD PRIMARY KEY (`IdFourPF`);

--
-- Index pour la table `histproduire`
--
ALTER TABLE `histproduire`
  ADD PRIMARY KEY (`IdProd`);

--
-- Index pour la table `histrequisitionner`
--
ALTER TABLE `histrequisitionner`
  ADD PRIMARY KEY (`IdReq`);

--
-- Index pour la table `hote`
--
ALTER TABLE `hote`
  ADD PRIMARY KEY (`Id`);

--
-- Index pour la table `logo`
--
ALTER TABLE `logo`
  ADD PRIMARY KEY (`IdLo`);

--
-- Index pour la table `matieresmp`
--
ALTER TABLE `matieresmp`
  ADD PRIMARY KEY (`IdMP`,`IdTypeMP`),
  ADD KEY `IdTypeMP` (`IdTypeMP`);

--
-- Index pour la table `pays`
--
ALTER TABLE `pays`
  ADD PRIMARY KEY (`IdP`);

--
-- Index pour la table `prix`
--
ALTER TABLE `prix`
  ADD PRIMARY KEY (`IdPrix`,`IdPF`),
  ADD KEY `IdPF` (`IdPF`);

--
-- Index pour la table `produirepf`
--
ALTER TABLE `produirepf`
  ADD PRIMARY KEY (`IdProd`,`IdReq`,`IdPF`),
  ADD KEY `IdComMP` (`IdReq`),
  ADD KEY `IdPF` (`IdPF`);

--
-- Index pour la table `produitsfinis`
--
ALTER TABLE `produitsfinis`
  ADD PRIMARY KEY (`IdPF`,`IdCat`),
  ADD KEY `IdCat` (`IdCat`);

--
-- Index pour la table `produits_image`
--
ALTER TABLE `produits_image`
  ADD PRIMARY KEY (`id_img`,`IdPF`);

--
-- Index pour la table `rel_retour_pf`
--
ALTER TABLE `rel_retour_pf`
  ADD PRIMARY KEY (`id_tpf`,`idpf`,`matricule`);

--
-- Index pour la table `rel_transfert_pf`
--
ALTER TABLE `rel_transfert_pf`
  ADD PRIMARY KEY (`id_tpf`,`idpf`,`matricule`);

--
-- Index pour la table `requisitionner`
--
ALTER TABLE `requisitionner`
  ADD PRIMARY KEY (`IdReq`,`Matricule`);

--
-- Index pour la table `tb_sous_stock`
--
ALTER TABLE `tb_sous_stock`
  ADD PRIMARY KEY (`id_sst`,`idpf`);

--
-- Index pour la table `tb_stock`
--
ALTER TABLE `tb_stock`
  ADD PRIMARY KEY (`idst`,`id`);

--
-- Index pour la table `typefournisseur`
--
ALTER TABLE `typefournisseur`
  ADD PRIMARY KEY (`IdTypeF`);

--
-- Index pour la table `type_matieresp`
--
ALTER TABLE `type_matieresp`
  ADD PRIMARY KEY (`IdTypeMP`);

--
-- Index pour la table `verser_monaie`
--
ALTER TABLE `verser_monaie`
  ADD PRIMARY KEY (`IdVerMonaie`,`IdCompte`,`Matricule`),
  ADD KEY `Matricule` (`Matricule`),
  ADD KEY `IdCompte` (`IdCompte`);

--
-- Index pour la table `ville`
--
ALTER TABLE `ville`
  ADD PRIMARY KEY (`IdV`,`IdP`),
  ADD KEY `IdP` (`IdP`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `banque`
--
ALTER TABLE `banque`
  MODIFY `IdBanque` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `caisse`
--
ALTER TABLE `caisse`
  MODIFY `IdCaisse` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `IdCat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `client`
--
ALTER TABLE `client`
  MODIFY `IdCli` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `commandemp`
--
ALTER TABLE `commandemp`
  MODIFY `IdComMP` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `commandepf`
--
ALTER TABLE `commandepf`
  MODIFY `IdComPF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT pour la table `compte`
--
ALTER TABLE `compte`
  MODIFY `IdCompte` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `contenir`
--
ALTER TABLE `contenir`
  MODIFY `IdCo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `contenir_req`
--
ALTER TABLE `contenir_req`
  MODIFY `IdConteReq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `depense`
--
ALTER TABLE `depense`
  MODIFY `iddepense` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `detaille_application`
--
ALTER TABLE `detaille_application`
  MODIFY `IdDetaille` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `exprimer`
--
ALTER TABLE `exprimer`
  MODIFY `IdExp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT pour la table `facture`
--
ALTER TABLE `facture`
  MODIFY `IdFact` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `fonction`
--
ALTER TABLE `fonction`
  MODIFY `IdFo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `fournirmp`
--
ALTER TABLE `fournirmp`
  MODIFY `IdFourMP` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `fournirpf`
--
ALTER TABLE `fournirpf`
  MODIFY `IdFourPF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT pour la table `fournisseur`
--
ALTER TABLE `fournisseur`
  MODIFY `IdF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `histcommandemp`
--
ALTER TABLE `histcommandemp`
  MODIFY `IdComMP` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `histcontenir`
--
ALTER TABLE `histcontenir`
  MODIFY `IdCo` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `histfacture`
--
ALTER TABLE `histfacture`
  MODIFY `IdFact` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `histfournirmp`
--
ALTER TABLE `histfournirmp`
  MODIFY `IdFourMP` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `histfournirpf`
--
ALTER TABLE `histfournirpf`
  MODIFY `IdFourPF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=117;

--
-- AUTO_INCREMENT pour la table `histproduire`
--
ALTER TABLE `histproduire`
  MODIFY `IdProd` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `histrequisitionner`
--
ALTER TABLE `histrequisitionner`
  MODIFY `IdReq` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `hote`
--
ALTER TABLE `hote`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT pour la table `logo`
--
ALTER TABLE `logo`
  MODIFY `IdLo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `matieresmp`
--
ALTER TABLE `matieresmp`
  MODIFY `IdMP` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pays`
--
ALTER TABLE `pays`
  MODIFY `IdP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=230;

--
-- AUTO_INCREMENT pour la table `prix`
--
ALTER TABLE `prix`
  MODIFY `IdPrix` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT pour la table `produirepf`
--
ALTER TABLE `produirepf`
  MODIFY `IdProd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `produitsfinis`
--
ALTER TABLE `produitsfinis`
  MODIFY `IdPF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=255;

--
-- AUTO_INCREMENT pour la table `produits_image`
--
ALTER TABLE `produits_image`
  MODIFY `id_img` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT pour la table `rel_retour_pf`
--
ALTER TABLE `rel_retour_pf`
  MODIFY `id_tpf` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `rel_transfert_pf`
--
ALTER TABLE `rel_transfert_pf`
  MODIFY `id_tpf` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `requisitionner`
--
ALTER TABLE `requisitionner`
  MODIFY `IdReq` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `tb_sous_stock`
--
ALTER TABLE `tb_sous_stock`
  MODIFY `id_sst` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `tb_stock`
--
ALTER TABLE `tb_stock`
  MODIFY `idst` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT pour la table `typefournisseur`
--
ALTER TABLE `typefournisseur`
  MODIFY `IdTypeF` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `type_matieresp`
--
ALTER TABLE `type_matieresp`
  MODIFY `IdTypeMP` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `verser_monaie`
--
ALTER TABLE `verser_monaie`
  MODIFY `IdVerMonaie` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `ville`
--
ALTER TABLE `ville`
  MODIFY `IdV` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
